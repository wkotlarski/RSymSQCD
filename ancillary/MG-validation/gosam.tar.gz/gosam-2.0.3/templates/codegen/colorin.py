parameters={	
   'TR' : 'real',
   'NC' : 'real',
   'NA' : 'real',
   'pi' : 'real',
   'i_' : 'complex',
   'T' : 'complex',
   'CC_' : 'complex',
   'incolors' : 'real',
   'numcs' : 'integer',
   'T T' : 'matrix',
   'cabb': 'array'
   } 

symbols = {
            'sqrt2' : 'sqrt2',
            'Sqrt2' : 'sqrt2',
            'Qt2' : 'mu2',
            '/' : '/' ,
         	'(' : '(' ,
           	')' : ')' ,
         	'^' : '**',
         	'+' : '+',
         	'-' : '-',
         	'*' : '*',
            'ZERO' : '0.0_ki'
	}

