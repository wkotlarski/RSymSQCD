#!/usr/bin/python
# vim: ts=3:sw=3

### [line replaced by setup.py - do not delete]

import golem.app.olp as app

if __name__ == "__main__":
	app.main()
