# This file was automatically created by FeynRules 2.3.15
# Mathematica version: 9.0 for Linux x86 (64-bit) (February 7, 2013)
# Date: Wed 17 Feb 2016 19:41:07


from object_library import all_vertices, all_CTvertices, Vertex, CTVertex
import particles as P
import CT_couplings as C
import lorentz as L


V_1 = CTVertex(name = 'V_1',
               type = 'R2',
               particles = [ P.g, P.g, P.g ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VVV1, L.VVV2, L.VVV4, L.VVV6, L.VVV7, L.VVV8 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ], [ [P.xglu] ] ],
               couplings = {(0,0,0):C.R2GC_356_117,(0,0,1):C.R2GC_356_118,(0,0,2):C.R2GC_264_83,(0,1,0):C.R2GC_359_119,(0,1,1):C.R2GC_359_120,(0,1,2):C.R2GC_263_81,(0,2,0):C.R2GC_359_119,(0,2,1):C.R2GC_359_120,(0,2,2):C.R2GC_263_81,(0,3,0):C.R2GC_356_117,(0,3,1):C.R2GC_356_118,(0,3,2):C.R2GC_264_83,(0,4,0):C.R2GC_356_117,(0,4,1):C.R2GC_356_118,(0,4,2):C.R2GC_264_83,(0,5,0):C.R2GC_359_119,(0,5,1):C.R2GC_359_120,(0,5,2):C.R2GC_263_81})

V_2 = CTVertex(name = 'V_2',
               type = 'R2',
               particles = [ P.g, P.g, P.g, P.g ],
               color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
               lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
               loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ], [ [P.xglu] ] ],
               couplings = {(2,0,0):C.R2GC_98_177,(2,0,1):C.R2GC_363_124,(2,0,2):C.R2GC_98_178,(0,0,0):C.R2GC_98_177,(0,0,1):C.R2GC_363_124,(0,0,2):C.R2GC_98_178,(4,0,0):C.R2GC_96_173,(4,0,1):C.R2GC_96_174,(4,0,2):C.R2GC_96_175,(3,0,0):C.R2GC_96_173,(3,0,1):C.R2GC_96_174,(3,0,2):C.R2GC_96_175,(8,0,0):C.R2GC_362_121,(8,0,1):C.R2GC_97_176,(8,0,2):C.R2GC_100_2,(6,0,0):C.R2GC_102_4,(6,0,1):C.R2GC_367_131,(6,0,2):C.R2GC_102_6,(7,0,0):C.R2GC_103_7,(7,0,1):C.R2GC_366_130,(7,0,2):C.R2GC_103_9,(5,0,0):C.R2GC_96_173,(5,0,1):C.R2GC_96_174,(5,0,2):C.R2GC_96_175,(1,0,0):C.R2GC_96_173,(1,0,1):C.R2GC_96_174,(1,0,2):C.R2GC_96_175,(11,0,0):C.R2GC_100_1,(11,0,1):C.R2GC_100_2,(11,0,2):C.R2GC_100_3,(10,0,0):C.R2GC_100_1,(10,0,1):C.R2GC_100_2,(10,0,2):C.R2GC_100_3,(9,0,1):C.R2GC_99_179,(9,0,2):C.R2GC_99_180,(2,1,0):C.R2GC_98_177,(2,1,1):C.R2GC_363_124,(2,1,2):C.R2GC_98_178,(0,1,0):C.R2GC_98_177,(0,1,1):C.R2GC_363_124,(0,1,2):C.R2GC_98_178,(4,1,0):C.R2GC_96_173,(4,1,1):C.R2GC_96_174,(4,1,2):C.R2GC_96_175,(3,1,0):C.R2GC_96_173,(3,1,1):C.R2GC_96_174,(3,1,2):C.R2GC_96_175,(8,1,0):C.R2GC_362_121,(8,1,1):C.R2GC_365_129,(8,1,2):C.R2GC_100_2,(6,1,0):C.R2GC_364_126,(6,1,1):C.R2GC_364_127,(6,1,2):C.R2GC_364_128,(7,1,0):C.R2GC_103_7,(7,1,1):C.R2GC_103_8,(7,1,2):C.R2GC_103_9,(5,1,0):C.R2GC_96_173,(5,1,1):C.R2GC_96_174,(5,1,2):C.R2GC_96_175,(1,1,0):C.R2GC_96_173,(1,1,1):C.R2GC_96_174,(1,1,2):C.R2GC_96_175,(11,1,0):C.R2GC_100_1,(11,1,1):C.R2GC_100_2,(11,1,2):C.R2GC_100_3,(10,1,0):C.R2GC_100_1,(10,1,1):C.R2GC_100_2,(10,1,2):C.R2GC_100_3,(9,1,1):C.R2GC_99_179,(9,1,2):C.R2GC_99_180,(0,2,0):C.R2GC_98_177,(0,2,1):C.R2GC_363_124,(0,2,2):C.R2GC_98_178,(2,2,0):C.R2GC_98_177,(2,2,1):C.R2GC_363_124,(2,2,2):C.R2GC_98_178,(5,2,0):C.R2GC_96_173,(5,2,1):C.R2GC_96_174,(5,2,2):C.R2GC_96_175,(1,2,0):C.R2GC_96_173,(1,2,1):C.R2GC_96_174,(1,2,2):C.R2GC_96_175,(7,2,0):C.R2GC_363_123,(7,2,1):C.R2GC_363_124,(7,2,2):C.R2GC_363_125,(4,2,0):C.R2GC_96_173,(4,2,1):C.R2GC_96_174,(4,2,2):C.R2GC_96_175,(3,2,0):C.R2GC_96_173,(3,2,1):C.R2GC_96_174,(3,2,2):C.R2GC_96_175,(8,2,0):C.R2GC_362_121,(8,2,1):C.R2GC_362_122,(8,2,2):C.R2GC_100_2,(6,2,0):C.R2GC_102_4,(6,2,1):C.R2GC_102_5,(6,2,2):C.R2GC_102_6,(11,2,0):C.R2GC_100_1,(11,2,1):C.R2GC_100_2,(11,2,2):C.R2GC_100_3,(10,2,0):C.R2GC_100_1,(10,2,1):C.R2GC_100_2,(10,2,2):C.R2GC_100_3,(9,2,1):C.R2GC_99_179,(9,2,2):C.R2GC_99_180})

V_3 = CTVertex(name = 'V_3',
               type = 'R2',
               particles = [ P.xglu__tilde__, P.xglu, P.g ],
               color = [ 'd(3,2,1)', 'f(3,2,1)' ],
               lorentz = [ L.FFV3, L.FFV4 ],
               loop_particles = [ [ [P.b, P.sbl], [P.b, P.sbr], [P.c, P.scl], [P.c, P.scr], [P.d, P.sdl], [P.d, P.sdr], [P.s, P.ssl], [P.s, P.ssr], [P.stl, P.t], [P.str, P.t], [P.sul, P.u], [P.sur, P.u] ], [ [P.b, P.sbl], [P.c, P.scl], [P.d, P.sdl], [P.s, P.ssl], [P.stl, P.t], [P.sul, P.u] ], [ [P.b, P.sbr], [P.c, P.scr], [P.d, P.sdr], [P.s, P.ssr], [P.str, P.t], [P.sur, P.u] ], [ [P.g, P.xglu] ], [ [P.sig8p, P.xglu], [P.sig8s, P.xglu] ] ],
               couplings = {(1,0,0):C.R2GC_391_141,(1,0,3):C.R2GC_391_142,(1,0,4):C.R2GC_391_143,(0,0,1):C.R2GC_93_171,(0,0,2):C.R2GC_93_172,(1,1,3):C.R2GC_391_142,(1,1,4):C.R2GC_391_143})

V_4 = CTVertex(name = 'V_4',
               type = 'R2',
               particles = [ P.t__tilde__, P.b, P.G__plus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS4 ],
               loop_particles = [ [ [P.b, P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_379_134})

V_5 = CTVertex(name = 'V_5',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.G0 ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_381_136})

V_6 = CTVertex(name = 'V_6',
               type = 'R2',
               particles = [ P.t__tilde__, P.t, P.H ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS2 ],
               loop_particles = [ [ [P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_380_135})

V_7 = CTVertex(name = 'V_7',
               type = 'R2',
               particles = [ P.b__tilde__, P.t, P.G__minus__ ],
               color = [ 'Identity(1,2)' ],
               lorentz = [ L.FFS3 ],
               loop_particles = [ [ [P.b, P.g, P.t] ] ],
               couplings = {(0,0,0):C.R2GC_378_133})

V_8 = CTVertex(name = 'V_8',
               type = 'R2',
               particles = [ P.xglu__tilde__, P.xglu, P.sig8p ],
               color = [ 'f(3,2,1)' ],
               lorentz = [ L.FFS1 ],
               loop_particles = [ [ [P.g, P.sig8p, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s, P.xglu] ] ],
               couplings = {(0,0,1):C.R2GC_261_75,(0,0,2):C.R2GC_261_76,(0,0,3):C.R2GC_261_77,(0,0,0):C.R2GC_261_78})

V_9 = CTVertex(name = 'V_9',
               type = 'R2',
               particles = [ P.g, P.sig8p, P.sig8p ],
               color = [ 'f(1,2,3)' ],
               lorentz = [ L.VSS1, L.VSS3 ],
               loop_particles = [ [ [P.g, P.sig8p] ], [ [P.xglu] ] ],
               couplings = {(0,0,1):C.R2GC_263_81,(0,0,0):C.R2GC_263_82,(0,1,1):C.R2GC_264_83,(0,1,0):C.R2GC_264_84})

V_10 = CTVertex(name = 'V_10',
                type = 'R2',
                particles = [ P.g, P.g, P.sig8p, P.sig8p ],
                color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.sig8p] ], [ [P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_103_7,(0,0,2):C.R2GC_162_46,(0,0,1):C.R2GC_162_47,(2,0,0):C.R2GC_103_7,(2,0,2):C.R2GC_162_46,(2,0,1):C.R2GC_162_47,(6,0,0):C.R2GC_103_7,(6,0,2):C.R2GC_265_85,(6,0,1):C.R2GC_265_86,(7,0,0):C.R2GC_103_7,(7,0,2):C.R2GC_265_85,(7,0,1):C.R2GC_265_86,(5,0,0):C.R2GC_161_43,(5,0,2):C.R2GC_161_44,(5,0,1):C.R2GC_161_45,(1,0,0):C.R2GC_161_43,(1,0,2):C.R2GC_161_44,(1,0,1):C.R2GC_161_45,(4,0,0):C.R2GC_161_43,(4,0,2):C.R2GC_161_44,(4,0,1):C.R2GC_161_45,(3,0,0):C.R2GC_161_43,(3,0,2):C.R2GC_161_44,(3,0,1):C.R2GC_161_45,(10,0,0):C.R2GC_162_46,(10,0,2):C.R2GC_164_50,(10,0,1):C.R2GC_164_51,(9,0,0):C.R2GC_162_46,(9,0,2):C.R2GC_164_50,(9,0,1):C.R2GC_164_51,(8,0,0):C.R2GC_102_4,(8,0,2):C.R2GC_163_48,(8,0,1):C.R2GC_163_49})

V_11 = CTVertex(name = 'V_11',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.xglu, P.sig8s ],
                color = [ 'f(3,2,1)' ],
                lorentz = [ L.FFS2 ],
                loop_particles = [ [ [P.g, P.sig8s, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_405_150,(0,0,2):C.R2GC_405_151,(0,0,3):C.R2GC_391_143,(0,0,0):C.R2GC_405_152})

V_12 = CTVertex(name = 'V_12',
                type = 'R2',
                particles = [ P.g, P.sig8s, P.sig8s ],
                color = [ 'f(1,2,3)' ],
                lorentz = [ L.VSS1, L.VSS3 ],
                loop_particles = [ [ [P.g, P.sig8s] ], [ [P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_263_81,(0,0,0):C.R2GC_263_82,(0,1,1):C.R2GC_264_83,(0,1,0):C.R2GC_264_84})

V_13 = CTVertex(name = 'V_13',
                type = 'R2',
                particles = [ P.g, P.g, P.sig8s, P.sig8s ],
                color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.sig8s] ], [ [P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_103_7,(0,0,2):C.R2GC_162_46,(0,0,1):C.R2GC_162_47,(2,0,0):C.R2GC_103_7,(2,0,2):C.R2GC_162_46,(2,0,1):C.R2GC_162_47,(6,0,0):C.R2GC_103_7,(6,0,2):C.R2GC_265_85,(6,0,1):C.R2GC_265_86,(7,0,0):C.R2GC_103_7,(7,0,2):C.R2GC_265_85,(7,0,1):C.R2GC_265_86,(5,0,0):C.R2GC_161_43,(5,0,2):C.R2GC_161_44,(5,0,1):C.R2GC_161_45,(1,0,0):C.R2GC_161_43,(1,0,2):C.R2GC_161_44,(1,0,1):C.R2GC_161_45,(4,0,0):C.R2GC_161_43,(4,0,2):C.R2GC_161_44,(4,0,1):C.R2GC_161_45,(3,0,0):C.R2GC_161_43,(3,0,2):C.R2GC_161_44,(3,0,1):C.R2GC_161_45,(10,0,0):C.R2GC_162_46,(10,0,2):C.R2GC_164_50,(10,0,1):C.R2GC_164_51,(9,0,0):C.R2GC_162_46,(9,0,2):C.R2GC_164_50,(9,0,1):C.R2GC_164_51,(8,0,0):C.R2GC_102_4,(8,0,2):C.R2GC_163_48,(8,0,1):C.R2GC_163_49})

V_14 = CTVertex(name = 'V_14',
                type = 'R2',
                particles = [ P.xglu, P.d, P.sdl__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.d, P.g, P.sdl] ], [ [P.d, P.g, P.xglu] ], [ [P.g, P.sdl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_15 = CTVertex(name = 'V_15',
                type = 'R2',
                particles = [ P.xglu, P.s, P.ssl__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.s, P.ssl] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_16 = CTVertex(name = 'V_16',
                type = 'R2',
                particles = [ P.xglu, P.b, P.sbl__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.b, P.g, P.sbl] ], [ [P.b, P.g, P.xglu] ], [ [P.g, P.sbl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_17 = CTVertex(name = 'V_17',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.d, P.sdr__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.d, P.g, P.sdr] ], [ [P.d, P.g, P.xglu] ], [ [P.g, P.sdr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_18 = CTVertex(name = 'V_18',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.s, P.ssr__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.s, P.ssr] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_19 = CTVertex(name = 'V_19',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.b, P.sbr__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.b, P.g, P.sbr] ], [ [P.b, P.g, P.xglu] ], [ [P.g, P.sbr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_20 = CTVertex(name = 'V_20',
                type = 'R2',
                particles = [ P.xglu, P.u, P.sul__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.sul, P.u] ], [ [P.g, P.sul, P.xglu] ], [ [P.g, P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_149,(0,0,2):C.R2GC_398_148})

V_21 = CTVertex(name = 'V_21',
                type = 'R2',
                particles = [ P.xglu, P.c, P.scl__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.c, P.g, P.scl] ], [ [P.c, P.g, P.xglu] ], [ [P.g, P.scl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_22 = CTVertex(name = 'V_22',
                type = 'R2',
                particles = [ P.xglu, P.t, P.stl__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.stl, P.t] ], [ [P.g, P.stl, P.xglu] ], [ [P.g, P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_149,(0,0,2):C.R2GC_398_148})

V_23 = CTVertex(name = 'V_23',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.u, P.sur__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.sur, P.u] ], [ [P.g, P.sur, P.xglu] ], [ [P.g, P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_146,(0,0,2):C.R2GC_392_145})

V_24 = CTVertex(name = 'V_24',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.c, P.scr__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.c, P.g, P.scr] ], [ [P.c, P.g, P.xglu] ], [ [P.g, P.scr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_25 = CTVertex(name = 'V_25',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.t, P.str__tilde__ ],
                color = [ 'T(1,2,3)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.str, P.t] ], [ [P.g, P.str, P.xglu] ], [ [P.g, P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_146,(0,0,2):C.R2GC_392_145})

V_26 = CTVertex(name = 'V_26',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.d__tilde__, P.sdl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.d, P.g, P.sdl] ], [ [P.d, P.g, P.xglu] ], [ [P.g, P.sdl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_27 = CTVertex(name = 'V_27',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.s__tilde__, P.ssl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.s, P.ssl] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_28 = CTVertex(name = 'V_28',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.b__tilde__, P.sbl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.b, P.g, P.sbl] ], [ [P.b, P.g, P.xglu] ], [ [P.g, P.sbl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_29 = CTVertex(name = 'V_29',
                type = 'R2',
                particles = [ P.d__tilde__, P.xglu, P.sdr ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.d, P.g, P.sdr] ], [ [P.d, P.g, P.xglu] ], [ [P.g, P.sdr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_30 = CTVertex(name = 'V_30',
                type = 'R2',
                particles = [ P.s__tilde__, P.xglu, P.ssr ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.s, P.ssr] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_31 = CTVertex(name = 'V_31',
                type = 'R2',
                particles = [ P.b__tilde__, P.xglu, P.sbr ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.b, P.g, P.sbr] ], [ [P.b, P.g, P.xglu] ], [ [P.g, P.sbr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_32 = CTVertex(name = 'V_32',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.u__tilde__, P.sul ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.sul, P.u] ], [ [P.g, P.sul, P.xglu] ], [ [P.g, P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_149,(0,0,2):C.R2GC_398_148})

V_33 = CTVertex(name = 'V_33',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.c__tilde__, P.scl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.c, P.g, P.scl] ], [ [P.c, P.g, P.xglu] ], [ [P.g, P.scl, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_148,(0,0,2):C.R2GC_398_149})

V_34 = CTVertex(name = 'V_34',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.t__tilde__, P.stl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.FFS3 ],
                loop_particles = [ [ [P.g, P.stl, P.t] ], [ [P.g, P.stl, P.xglu] ], [ [P.g, P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_398_147,(0,0,1):C.R2GC_398_149,(0,0,2):C.R2GC_398_148})

V_35 = CTVertex(name = 'V_35',
                type = 'R2',
                particles = [ P.u__tilde__, P.xglu, P.sur ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.sur, P.u] ], [ [P.g, P.sur, P.xglu] ], [ [P.g, P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_146,(0,0,2):C.R2GC_392_145})

V_36 = CTVertex(name = 'V_36',
                type = 'R2',
                particles = [ P.c__tilde__, P.xglu, P.scr ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.c, P.g, P.scr] ], [ [P.c, P.g, P.xglu] ], [ [P.g, P.scr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_145,(0,0,2):C.R2GC_392_146})

V_37 = CTVertex(name = 'V_37',
                type = 'R2',
                particles = [ P.t__tilde__, P.xglu, P.str ],
                color = [ 'T(2,3,1)' ],
                lorentz = [ L.FFS4 ],
                loop_particles = [ [ [P.g, P.str, P.t] ], [ [P.g, P.str, P.xglu] ], [ [P.g, P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_392_144,(0,0,1):C.R2GC_392_146,(0,0,2):C.R2GC_392_145})

V_38 = CTVertex(name = 'V_38',
                type = 'R2',
                particles = [ P.sdl__tilde__, P.sdl, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdl] ], [ [P.g, P.sdl, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_235_67,(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_69})

V_39 = CTVertex(name = 'V_39',
                type = 'R2',
                particles = [ P.sig8s, P.ssl__tilde__, P.ssl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.ssl] ], [ [P.g, P.ssl] ], [ [P.s, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_67,(0,0,0):C.R2GC_235_69})

V_40 = CTVertex(name = 'V_40',
                type = 'R2',
                particles = [ P.sbl__tilde__, P.sbl, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbl] ], [ [P.g, P.sbl, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_235_67,(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_69})

V_41 = CTVertex(name = 'V_41',
                type = 'R2',
                particles = [ P.sdr__tilde__, P.sdr, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdr] ], [ [P.g, P.sdr, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_236_70,(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_72})

V_42 = CTVertex(name = 'V_42',
                type = 'R2',
                particles = [ P.sig8s, P.ssr__tilde__, P.ssr ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.ssr] ], [ [P.g, P.ssr] ], [ [P.s, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_70,(0,0,0):C.R2GC_236_72})

V_43 = CTVertex(name = 'V_43',
                type = 'R2',
                particles = [ P.sbr__tilde__, P.sbr, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbr] ], [ [P.g, P.sbr, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_236_70,(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_72})

V_44 = CTVertex(name = 'V_44',
                type = 'R2',
                particles = [ P.sig8s, P.sul__tilde__, P.sul ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.sul] ], [ [P.g, P.sul] ], [ [P.u, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_67,(0,0,0):C.R2GC_235_69})

V_45 = CTVertex(name = 'V_45',
                type = 'R2',
                particles = [ P.scl__tilde__, P.scl, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scl] ], [ [P.g, P.scl, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_235_67,(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_69})

V_46 = CTVertex(name = 'V_46',
                type = 'R2',
                particles = [ P.sig8s, P.stl__tilde__, P.stl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.stl] ], [ [P.g, P.stl] ], [ [P.t, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_235_68,(0,0,2):C.R2GC_235_67,(0,0,0):C.R2GC_235_69})

V_47 = CTVertex(name = 'V_47',
                type = 'R2',
                particles = [ P.sig8s, P.sur__tilde__, P.sur ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.sur] ], [ [P.g, P.sur] ], [ [P.u, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_70,(0,0,0):C.R2GC_236_72})

V_48 = CTVertex(name = 'V_48',
                type = 'R2',
                particles = [ P.scr__tilde__, P.scr, P.sig8s ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scr] ], [ [P.g, P.scr, P.sig8s] ] ],
                couplings = {(0,0,0):C.R2GC_236_70,(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_72})

V_49 = CTVertex(name = 'V_49',
                type = 'R2',
                particles = [ P.sig8s, P.str__tilde__, P.str ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.SSS1 ],
                loop_particles = [ [ [P.g, P.sig8s, P.str] ], [ [P.g, P.str] ], [ [P.t, P.xglu] ] ],
                couplings = {(0,0,1):C.R2GC_236_71,(0,0,2):C.R2GC_236_70,(0,0,0):C.R2GC_236_72})

V_50 = CTVertex(name = 'V_50',
                type = 'R2',
                particles = [ P.g, P.sul__tilde__, P.sul ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.sul] ], [ [P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_51 = CTVertex(name = 'V_51',
                type = 'R2',
                particles = [ P.g, P.scl__tilde__, P.scl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scl] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_52 = CTVertex(name = 'V_52',
                type = 'R2',
                particles = [ P.g, P.stl__tilde__, P.stl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.stl] ], [ [P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_53 = CTVertex(name = 'V_53',
                type = 'R2',
                particles = [ P.g, P.g, P.sul__tilde__, P.sul ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.sul] ], [ [P.u, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_54 = CTVertex(name = 'V_54',
                type = 'R2',
                particles = [ P.g, P.g, P.scl__tilde__, P.scl ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g] ], [ [P.g, P.scl] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_55 = CTVertex(name = 'V_55',
                type = 'R2',
                particles = [ P.g, P.g, P.stl__tilde__, P.stl ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.stl] ], [ [P.t, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_56 = CTVertex(name = 'V_56',
                type = 'R2',
                particles = [ P.g, P.sur__tilde__, P.sur ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.sur] ], [ [P.u, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_57 = CTVertex(name = 'V_57',
                type = 'R2',
                particles = [ P.g, P.scr__tilde__, P.scr ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scr] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_58 = CTVertex(name = 'V_58',
                type = 'R2',
                particles = [ P.g, P.str__tilde__, P.str ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.str] ], [ [P.t, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_59 = CTVertex(name = 'V_59',
                type = 'R2',
                particles = [ P.g, P.g, P.sur__tilde__, P.sur ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.sur] ], [ [P.u, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_60 = CTVertex(name = 'V_60',
                type = 'R2',
                particles = [ P.g, P.g, P.scr__tilde__, P.scr ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.c, P.xglu] ], [ [P.g] ], [ [P.g, P.scr] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_61 = CTVertex(name = 'V_61',
                type = 'R2',
                particles = [ P.g, P.g, P.str__tilde__, P.str ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.str] ], [ [P.t, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_62 = CTVertex(name = 'V_62',
                type = 'R2',
                particles = [ P.g, P.sdl__tilde__, P.sdl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdl] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_63 = CTVertex(name = 'V_63',
                type = 'R2',
                particles = [ P.g, P.ssl__tilde__, P.ssl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.ssl] ], [ [P.s, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_64 = CTVertex(name = 'V_64',
                type = 'R2',
                particles = [ P.g, P.sbl__tilde__, P.sbl ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbl] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_65 = CTVertex(name = 'V_65',
                type = 'R2',
                particles = [ P.g, P.g, P.sdl__tilde__, P.sdl ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g] ], [ [P.g, P.sdl] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_66 = CTVertex(name = 'V_66',
                type = 'R2',
                particles = [ P.g, P.g, P.ssl__tilde__, P.ssl ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.ssl] ], [ [P.s, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_67 = CTVertex(name = 'V_67',
                type = 'R2',
                particles = [ P.g, P.g, P.sbl__tilde__, P.sbl ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g] ], [ [P.g, P.sbl] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_68 = CTVertex(name = 'V_68',
                type = 'R2',
                particles = [ P.g, P.sdr__tilde__, P.sdr ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdr] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_69 = CTVertex(name = 'V_69',
                type = 'R2',
                particles = [ P.g, P.ssr__tilde__, P.ssr ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.g, P.ssr] ], [ [P.s, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_272_94,(0,0,1):C.R2GC_272_93})

V_70 = CTVertex(name = 'V_70',
                type = 'R2',
                particles = [ P.g, P.sbr__tilde__, P.sbr ],
                color = [ 'T(1,3,2)' ],
                lorentz = [ L.VSS2 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbr] ] ],
                couplings = {(0,0,0):C.R2GC_272_93,(0,0,1):C.R2GC_272_94})

V_71 = CTVertex(name = 'V_71',
                type = 'R2',
                particles = [ P.g, P.g, P.sdr__tilde__, P.sdr ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.d, P.xglu] ], [ [P.g] ], [ [P.g, P.sdr] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_72 = CTVertex(name = 'V_72',
                type = 'R2',
                particles = [ P.g, P.g, P.ssr__tilde__, P.ssr ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.g] ], [ [P.g, P.ssr] ], [ [P.s, P.xglu] ] ],
                couplings = {(2,0,0):C.R2GC_162_46,(2,0,1):C.R2GC_273_96,(2,0,2):C.R2GC_273_95,(1,0,0):C.R2GC_162_46,(1,0,1):C.R2GC_273_96,(1,0,2):C.R2GC_273_95,(0,0,0):C.R2GC_100_2,(0,0,1):C.R2GC_155_42,(0,0,2):C.R2GC_102_4})

V_73 = CTVertex(name = 'V_73',
                type = 'R2',
                particles = [ P.g, P.g, P.sbr__tilde__, P.sbr ],
                color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                lorentz = [ L.VVSS1 ],
                loop_particles = [ [ [P.b, P.xglu] ], [ [P.g] ], [ [P.g, P.sbr] ] ],
                couplings = {(2,0,1):C.R2GC_162_46,(2,0,0):C.R2GC_273_95,(2,0,2):C.R2GC_273_96,(1,0,1):C.R2GC_162_46,(1,0,0):C.R2GC_273_95,(1,0,2):C.R2GC_273_96,(0,0,1):C.R2GC_100_2,(0,0,0):C.R2GC_102_4,(0,0,2):C.R2GC_155_42})

V_74 = CTVertex(name = 'V_74',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_122_27})

V_75 = CTVertex(name = 'V_75',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_122_27})

V_76 = CTVertex(name = 'V_76',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_122_27})

V_77 = CTVertex(name = 'V_77',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_78 = CTVertex(name = 'V_78',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g] ], [ [P.scl, P.xglu] ], [ [P.scr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_79 = CTVertex(name = 'V_79',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_80 = CTVertex(name = 'V_80',
                type = 'R2',
                particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_81 = CTVertex(name = 'V_81',
                type = 'R2',
                particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_82 = CTVertex(name = 'V_82',
                type = 'R2',
                particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_83 = CTVertex(name = 'V_83',
                type = 'R2',
                particles = [ P.u__tilde__, P.u, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_286_101,(0,1,0):C.R2GC_294_103})

V_84 = CTVertex(name = 'V_84',
                type = 'R2',
                particles = [ P.c__tilde__, P.c, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.c, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_286_101,(0,1,0):C.R2GC_294_103})

V_85 = CTVertex(name = 'V_85',
                type = 'R2',
                particles = [ P.t__tilde__, P.t, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_286_101,(0,1,0):C.R2GC_294_103})

V_86 = CTVertex(name = 'V_86',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_105_11})

V_87 = CTVertex(name = 'V_87',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_105_11})

V_88 = CTVertex(name = 'V_88',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.a ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV1 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_105_11})

V_89 = CTVertex(name = 'V_89',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.d, P.g] ], [ [P.sdl, P.xglu] ], [ [P.sdr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_90 = CTVertex(name = 'V_90',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.s] ], [ [P.ssl, P.xglu] ], [ [P.ssr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_91 = CTVertex(name = 'V_91',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.g ],
                color = [ 'T(3,2,1)' ],
                lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.b, P.g] ], [ [P.sbl, P.xglu] ], [ [P.sbr, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_106_12,(0,1,1):C.R2GC_269_89,(0,2,2):C.R2GC_269_89})

V_92 = CTVertex(name = 'V_92',
                type = 'R2',
                particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.d, P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_93 = CTVertex(name = 'V_93',
                type = 'R2',
                particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.c, P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_94 = CTVertex(name = 'V_94',
                type = 'R2',
                particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3 ],
                loop_particles = [ [ [P.b, P.g, P.t] ] ],
                couplings = {(0,0,0):C.R2GC_318_107})

V_95 = CTVertex(name = 'V_95',
                type = 'R2',
                particles = [ P.d__tilde__, P.d, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.d, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_270_90,(0,1,0):C.R2GC_278_99})

V_96 = CTVertex(name = 'V_96',
                type = 'R2',
                particles = [ P.s__tilde__, P.s, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.g, P.s] ] ],
                couplings = {(0,0,0):C.R2GC_270_90,(0,1,0):C.R2GC_278_99})

V_97 = CTVertex(name = 'V_97',
                type = 'R2',
                particles = [ P.b__tilde__, P.b, P.Z ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FFV3, L.FFV4 ],
                loop_particles = [ [ [P.b, P.g] ] ],
                couplings = {(0,0,0):C.R2GC_270_90,(0,1,0):C.R2GC_278_99})

V_98 = CTVertex(name = 'V_98',
                type = 'R2',
                particles = [ P.xglu__tilde__, P.xglu ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF2, L.FF3, L.FF4, L.FF5 ],
                loop_particles = [ [ [P.g, P.xglu] ] ],
                couplings = {(0,0,0):C.R2GC_409_153,(0,2,0):C.R2GC_409_153,(0,1,0):C.R2GC_390_140,(0,3,0):C.R2GC_390_140})

V_99 = CTVertex(name = 'V_99',
                type = 'R2',
                particles = [ P.u__tilde__, P.u ],
                color = [ 'Identity(1,2)' ],
                lorentz = [ L.FF1 ],
                loop_particles = [ [ [P.g, P.u] ] ],
                couplings = {(0,0,0):C.R2GC_104_10})

V_100 = CTVertex(name = 'V_100',
                 type = 'R2',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.c, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_104_10})

V_101 = CTVertex(name = 'V_101',
                 type = 'R2',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF2, L.FF3, L.FF4, L.FF5 ],
                 loop_particles = [ [ [P.g, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_371_132,(0,2,0):C.R2GC_371_132,(0,3,0):C.R2GC_104_10,(0,1,0):C.R2GC_104_10})

V_102 = CTVertex(name = 'V_102',
                 type = 'R2',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.d, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_104_10})

V_103 = CTVertex(name = 'V_103',
                 type = 'R2',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.g, P.s] ] ],
                 couplings = {(0,0,0):C.R2GC_104_10})

V_104 = CTVertex(name = 'V_104',
                 type = 'R2',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1 ],
                 loop_particles = [ [ [P.b, P.g] ] ],
                 couplings = {(0,0,0):C.R2GC_104_10})

V_105 = CTVertex(name = 'V_105',
                 type = 'R2',
                 particles = [ P.sig8s, P.sig8s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS3 ],
                 loop_particles = [ [ [P.g, P.sig8s] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.R2GC_266_87,(0,0,0):C.R2GC_349_111,(0,1,1):C.R2GC_262_79,(0,1,0):C.R2GC_262_80})

V_106 = CTVertex(name = 'V_106',
                 type = 'R2',
                 particles = [ P.sig8p, P.sig8p ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS3 ],
                 loop_particles = [ [ [P.g, P.sig8p] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.R2GC_266_87,(0,0,0):C.R2GC_266_88,(0,1,1):C.R2GC_262_79,(0,1,0):C.R2GC_262_80})

V_107 = CTVertex(name = 'V_107',
                 type = 'R2',
                 particles = [ P.sul__tilde__, P.sul ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.sul] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_340_110,(0,0,1):C.R2GC_274_97,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_108 = CTVertex(name = 'V_108',
                 type = 'R2',
                 particles = [ P.scl__tilde__, P.scl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scl] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_290_102,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_109 = CTVertex(name = 'V_109',
                 type = 'R2',
                 particles = [ P.stl__tilde__, P.stl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.stl] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_385_137,(0,0,1):C.R2GC_385_138,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_110 = CTVertex(name = 'V_110',
                 type = 'R2',
                 particles = [ P.sur__tilde__, P.sur ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.sur] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_353_112,(0,0,1):C.R2GC_274_97,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_111 = CTVertex(name = 'V_111',
                 type = 'R2',
                 particles = [ P.scr__tilde__, P.scr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scr] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_298_104,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_112 = CTVertex(name = 'V_112',
                 type = 'R2',
                 particles = [ P.str__tilde__, P.str ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.str] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_389_139,(0,0,1):C.R2GC_385_138,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_113 = CTVertex(name = 'V_113',
                 type = 'R2',
                 particles = [ P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdl] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_306_105,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_114 = CTVertex(name = 'V_114',
                 type = 'R2',
                 particles = [ P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.ssl] ], [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_323_108,(0,0,1):C.R2GC_274_97,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_115 = CTVertex(name = 'V_115',
                 type = 'R2',
                 particles = [ P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbl] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_274_98,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_116 = CTVertex(name = 'V_116',
                 type = 'R2',
                 particles = [ P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdr] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_314_106,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_117 = CTVertex(name = 'V_117',
                 type = 'R2',
                 particles = [ P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.ssr] ], [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_331_109,(0,0,1):C.R2GC_274_97,(0,1,0):C.R2GC_271_92,(0,1,1):C.R2GC_271_91})

V_118 = CTVertex(name = 'V_118',
                 type = 'R2',
                 particles = [ P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbr] ] ],
                 couplings = {(0,0,0):C.R2GC_274_97,(0,0,1):C.R2GC_282_100,(0,1,0):C.R2GC_271_91,(0,1,1):C.R2GC_271_92})

V_119 = CTVertex(name = 'V_119',
                 type = 'R2',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV2, L.VV3 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.g] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.R2GC_355_116,(0,1,2):C.R2GC_91_168,(0,1,3):C.R2GC_91_169,(0,2,0):C.R2GC_354_113,(0,2,1):C.R2GC_354_114,(0,2,3):C.R2GC_354_115})

V_120 = CTVertex(name = 'V_120',
                 type = 'R2',
                 particles = [ P.xglu__tilde__, P.xglu, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.sbl], [P.d, P.sdl], [P.s, P.ssl] ], [ [P.b, P.sbr], [P.d, P.sdr], [P.s, P.ssr] ], [ [P.c, P.scl], [P.stl, P.t], [P.sul, P.u] ], [ [P.c, P.scr], [P.str, P.t], [P.sur, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_212_53,(0,0,1):C.R2GC_212_54,(0,0,2):C.R2GC_212_55,(0,0,3):C.R2GC_212_56})

V_121 = CTVertex(name = 'V_121',
                 type = 'R2',
                 particles = [ P.xglu__tilde__, P.xglu, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.sbl], [P.d, P.sdl], [P.s, P.ssl] ], [ [P.b, P.sbr], [P.d, P.sdr], [P.s, P.ssr] ], [ [P.c, P.scl], [P.stl, P.t], [P.sul, P.u] ], [ [P.c, P.scr], [P.str, P.t], [P.sur, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_213_57,(0,0,1):C.R2GC_213_58,(0,0,2):C.R2GC_213_59,(0,0,3):C.R2GC_213_60})

V_122 = CTVertex(name = 'V_122',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVS1 ],
                 loop_particles = [ [ [P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_82_154})

V_123 = CTVertex(name = 'V_123',
                 type = 'R2',
                 particles = [ P.a, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_124 = CTVertex(name = 'V_124',
                 type = 'R2',
                 particles = [ P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_128_32,(0,1,0):C.R2GC_129_33})

V_125 = CTVertex(name = 'V_125',
                 type = 'R2',
                 particles = [ P.a, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_126 = CTVertex(name = 'V_126',
                 type = 'R2',
                 particles = [ P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_128_32,(0,1,0):C.R2GC_129_33})

V_127 = CTVertex(name = 'V_127',
                 type = 'R2',
                 particles = [ P.a, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_128 = CTVertex(name = 'V_128',
                 type = 'R2',
                 particles = [ P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_128_32,(0,1,0):C.R2GC_129_33})

V_129 = CTVertex(name = 'V_129',
                 type = 'R2',
                 particles = [ P.a, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_130 = CTVertex(name = 'V_130',
                 type = 'R2',
                 particles = [ P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_130_34,(0,1,0):C.R2GC_131_35})

V_131 = CTVertex(name = 'V_131',
                 type = 'R2',
                 particles = [ P.a, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_132 = CTVertex(name = 'V_132',
                 type = 'R2',
                 particles = [ P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_130_34,(0,1,0):C.R2GC_131_35})

V_133 = CTVertex(name = 'V_133',
                 type = 'R2',
                 particles = [ P.a, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_125_29,(0,1,0):C.R2GC_124_28})

V_134 = CTVertex(name = 'V_134',
                 type = 'R2',
                 particles = [ P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_130_34,(0,1,0):C.R2GC_131_35})

V_135 = CTVertex(name = 'V_135',
                 type = 'R2',
                 particles = [ P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_231_63,(0,1,0):C.R2GC_232_64})

V_136 = CTVertex(name = 'V_136',
                 type = 'R2',
                 particles = [ P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_232_64,(0,1,0):C.R2GC_231_63})

V_137 = CTVertex(name = 'V_137',
                 type = 'R2',
                 particles = [ P.a, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_138 = CTVertex(name = 'V_138',
                 type = 'R2',
                 particles = [ P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_111_17,(0,1,0):C.R2GC_112_18})

V_139 = CTVertex(name = 'V_139',
                 type = 'R2',
                 particles = [ P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_232_64,(0,1,0):C.R2GC_231_63})

V_140 = CTVertex(name = 'V_140',
                 type = 'R2',
                 particles = [ P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_231_63,(0,1,0):C.R2GC_232_64})

V_141 = CTVertex(name = 'V_141',
                 type = 'R2',
                 particles = [ P.a, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_142 = CTVertex(name = 'V_142',
                 type = 'R2',
                 particles = [ P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_111_17,(0,1,0):C.R2GC_112_18})

V_143 = CTVertex(name = 'V_143',
                 type = 'R2',
                 particles = [ P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_231_63,(0,1,0):C.R2GC_232_64})

V_144 = CTVertex(name = 'V_144',
                 type = 'R2',
                 particles = [ P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_232_64,(0,1,0):C.R2GC_231_63})

V_145 = CTVertex(name = 'V_145',
                 type = 'R2',
                 particles = [ P.a, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_146 = CTVertex(name = 'V_146',
                 type = 'R2',
                 particles = [ P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_111_17,(0,1,0):C.R2GC_112_18})

V_147 = CTVertex(name = 'V_147',
                 type = 'R2',
                 particles = [ P.a, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_148 = CTVertex(name = 'V_148',
                 type = 'R2',
                 particles = [ P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_114_20,(0,1,0):C.R2GC_113_19})

V_149 = CTVertex(name = 'V_149',
                 type = 'R2',
                 particles = [ P.a, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_150 = CTVertex(name = 'V_150',
                 type = 'R2',
                 particles = [ P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_114_20,(0,1,0):C.R2GC_113_19})

V_151 = CTVertex(name = 'V_151',
                 type = 'R2',
                 particles = [ P.a, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_107_13,(0,1,0):C.R2GC_108_14})

V_152 = CTVertex(name = 'V_152',
                 type = 'R2',
                 particles = [ P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_114_20,(0,1,0):C.R2GC_113_19})

V_153 = CTVertex(name = 'V_153',
                 type = 'R2',
                 particles = [ P.H, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_208_52})

V_154 = CTVertex(name = 'V_154',
                 type = 'R2',
                 particles = [ P.H, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_208_52})

V_155 = CTVertex(name = 'V_155',
                 type = 'R2',
                 particles = [ P.G__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_254_74})

V_156 = CTVertex(name = 'V_156',
                 type = 'R2',
                 particles = [ P.G__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_253_73})

V_157 = CTVertex(name = 'V_157',
                 type = 'R2',
                 particles = [ P.g, P.g, P.W__minus__, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV6 ],
                 loop_particles = [ [ [P.b, P.t], [P.c, P.s], [P.d, P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_92_170})

V_158 = CTVertex(name = 'V_158',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.Z ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VVVV6 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_87_160,(0,0,1):C.R2GC_87_161})

V_159 = CTVertex(name = 'V_159',
                 type = 'R2',
                 particles = [ P.g, P.g, P.Z, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVVV6 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_90_166,(0,0,1):C.R2GC_90_167})

V_160 = CTVertex(name = 'V_160',
                 type = 'R2',
                 particles = [ P.a, P.a, P.g, P.g ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVVV6 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_85_156,(0,0,1):C.R2GC_85_157})

V_161 = CTVertex(name = 'V_161',
                 type = 'R2',
                 particles = [ P.g, P.g, P.g, P.Z ],
                 color = [ 'd(1,2,3)', 'f(1,2,3)' ],
                 lorentz = [ L.VVVV1, L.VVVV6 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(1,0,0):C.R2GC_89_164,(1,0,1):C.R2GC_89_165,(0,1,0):C.R2GC_88_162,(0,1,1):C.R2GC_88_163})

V_162 = CTVertex(name = 'V_162',
                 type = 'R2',
                 particles = [ P.a, P.g, P.g, P.g ],
                 color = [ 'd(2,3,4)' ],
                 lorentz = [ L.VVVV6 ],
                 loop_particles = [ [ [P.b], [P.d], [P.s] ], [ [P.c], [P.t], [P.u] ] ],
                 couplings = {(0,0,0):C.R2GC_86_158,(0,0,1):C.R2GC_86_159})

V_163 = CTVertex(name = 'V_163',
                 type = 'R2',
                 particles = [ P.g, P.g, P.H, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_83_155})

V_164 = CTVertex(name = 'V_164',
                 type = 'R2',
                 particles = [ P.g, P.g, P.G0, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_83_155})

V_165 = CTVertex(name = 'V_165',
                 type = 'R2',
                 particles = [ P.g, P.g, P.G__minus__, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t] ] ],
                 couplings = {(0,0,0):C.R2GC_83_155})

V_166 = CTVertex(name = 'V_166',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_167 = CTVertex(name = 'V_167',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_168 = CTVertex(name = 'V_168',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_132_36})

V_169 = CTVertex(name = 'V_169',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_136_40})

V_170 = CTVertex(name = 'V_170',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sul__tilde__, P.sul ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_171 = CTVertex(name = 'V_171',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_134_38})

V_172 = CTVertex(name = 'V_172',
                 type = 'R2',
                 particles = [ P.a, P.a, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_173 = CTVertex(name = 'V_173',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_174 = CTVertex(name = 'V_174',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_132_36})

V_175 = CTVertex(name = 'V_175',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_136_40})

V_176 = CTVertex(name = 'V_176',
                 type = 'R2',
                 particles = [ P.a, P.g, P.scl__tilde__, P.scl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_177 = CTVertex(name = 'V_177',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_134_38})

V_178 = CTVertex(name = 'V_178',
                 type = 'R2',
                 particles = [ P.a, P.a, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_179 = CTVertex(name = 'V_179',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_180 = CTVertex(name = 'V_180',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_132_36})

V_181 = CTVertex(name = 'V_181',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_136_40})

V_182 = CTVertex(name = 'V_182',
                 type = 'R2',
                 particles = [ P.a, P.g, P.stl__tilde__, P.stl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_183 = CTVertex(name = 'V_183',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_134_38})

V_184 = CTVertex(name = 'V_184',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_185 = CTVertex(name = 'V_185',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_133_37})

V_186 = CTVertex(name = 'V_186',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_137_41})

V_187 = CTVertex(name = 'V_187',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sur__tilde__, P.sur ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_188 = CTVertex(name = 'V_188',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_135_39})

V_189 = CTVertex(name = 'V_189',
                 type = 'R2',
                 particles = [ P.a, P.a, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_190 = CTVertex(name = 'V_190',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_133_37})

V_191 = CTVertex(name = 'V_191',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_137_41})

V_192 = CTVertex(name = 'V_192',
                 type = 'R2',
                 particles = [ P.a, P.g, P.scr__tilde__, P.scr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_193 = CTVertex(name = 'V_193',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_135_39})

V_194 = CTVertex(name = 'V_194',
                 type = 'R2',
                 particles = [ P.a, P.a, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_126_30})

V_195 = CTVertex(name = 'V_195',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_133_37})

V_196 = CTVertex(name = 'V_196',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_137_41})

V_197 = CTVertex(name = 'V_197',
                 type = 'R2',
                 particles = [ P.a, P.g, P.str__tilde__, P.str ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_127_31})

V_198 = CTVertex(name = 'V_198',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.str__tilde__, P.str ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_135_39})

V_199 = CTVertex(name = 'V_199',
                 type = 'R2',
                 particles = [ P.a, P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_200 = CTVertex(name = 'V_200',
                 type = 'R2',
                 particles = [ P.W__plus__, P.Z, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_201 = CTVertex(name = 'V_201',
                 type = 'R2',
                 particles = [ P.g, P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_202 = CTVertex(name = 'V_202',
                 type = 'R2',
                 particles = [ P.a, P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_203 = CTVertex(name = 'V_203',
                 type = 'R2',
                 particles = [ P.W__minus__, P.Z, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_204 = CTVertex(name = 'V_204',
                 type = 'R2',
                 particles = [ P.g, P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_205 = CTVertex(name = 'V_205',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_206 = CTVertex(name = 'V_206',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_207 = CTVertex(name = 'V_207',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_115_21})

V_208 = CTVertex(name = 'V_208',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_119_25})

V_209 = CTVertex(name = 'V_209',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sdl__tilde__, P.sdl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_210 = CTVertex(name = 'V_210',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_117_23})

V_211 = CTVertex(name = 'V_211',
                 type = 'R2',
                 particles = [ P.a, P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_212 = CTVertex(name = 'V_212',
                 type = 'R2',
                 particles = [ P.W__plus__, P.Z, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_213 = CTVertex(name = 'V_213',
                 type = 'R2',
                 particles = [ P.g, P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_214 = CTVertex(name = 'V_214',
                 type = 'R2',
                 particles = [ P.a, P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_215 = CTVertex(name = 'V_215',
                 type = 'R2',
                 particles = [ P.W__minus__, P.Z, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_216 = CTVertex(name = 'V_216',
                 type = 'R2',
                 particles = [ P.g, P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_217 = CTVertex(name = 'V_217',
                 type = 'R2',
                 particles = [ P.a, P.a, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_218 = CTVertex(name = 'V_218',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_219 = CTVertex(name = 'V_219',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_115_21})

V_220 = CTVertex(name = 'V_220',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_119_25})

V_221 = CTVertex(name = 'V_221',
                 type = 'R2',
                 particles = [ P.a, P.g, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_222 = CTVertex(name = 'V_222',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_117_23})

V_223 = CTVertex(name = 'V_223',
                 type = 'R2',
                 particles = [ P.a, P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_224 = CTVertex(name = 'V_224',
                 type = 'R2',
                 particles = [ P.W__plus__, P.Z, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_225 = CTVertex(name = 'V_225',
                 type = 'R2',
                 particles = [ P.g, P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_226 = CTVertex(name = 'V_226',
                 type = 'R2',
                 particles = [ P.a, P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_233_65})

V_227 = CTVertex(name = 'V_227',
                 type = 'R2',
                 particles = [ P.W__minus__, P.Z, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_229_61})

V_228 = CTVertex(name = 'V_228',
                 type = 'R2',
                 particles = [ P.g, P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_234_66})

V_229 = CTVertex(name = 'V_229',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_230 = CTVertex(name = 'V_230',
                 type = 'R2',
                 particles = [ P.W__minus__, P.W__plus__, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_230_62})

V_231 = CTVertex(name = 'V_231',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_115_21})

V_232 = CTVertex(name = 'V_232',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_119_25})

V_233 = CTVertex(name = 'V_233',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sbl__tilde__, P.sbl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_234 = CTVertex(name = 'V_234',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_117_23})

V_235 = CTVertex(name = 'V_235',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_236 = CTVertex(name = 'V_236',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_116_22})

V_237 = CTVertex(name = 'V_237',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_120_26})

V_238 = CTVertex(name = 'V_238',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sdr__tilde__, P.sdr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_239 = CTVertex(name = 'V_239',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_118_24})

V_240 = CTVertex(name = 'V_240',
                 type = 'R2',
                 particles = [ P.a, P.a, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_241 = CTVertex(name = 'V_241',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_116_22})

V_242 = CTVertex(name = 'V_242',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_120_26})

V_243 = CTVertex(name = 'V_243',
                 type = 'R2',
                 particles = [ P.a, P.g, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_244 = CTVertex(name = 'V_244',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_118_24})

V_245 = CTVertex(name = 'V_245',
                 type = 'R2',
                 particles = [ P.a, P.a, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_109_15})

V_246 = CTVertex(name = 'V_246',
                 type = 'R2',
                 particles = [ P.a, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_116_22})

V_247 = CTVertex(name = 'V_247',
                 type = 'R2',
                 particles = [ P.Z, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_120_26})

V_248 = CTVertex(name = 'V_248',
                 type = 'R2',
                 particles = [ P.a, P.g, P.sbr__tilde__, P.sbr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_110_16})

V_249 = CTVertex(name = 'V_249',
                 type = 'R2',
                 particles = [ P.g, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.R2GC_118_24})

V_250 = CTVertex(name = 'V_250',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g ],
                 color = [ 'f(1,2,3)' ],
                 lorentz = [ L.VVV1, L.VVV2, L.VVV3, L.VVV4, L.VVV5, L.VVV6, L.VVV7, L.VVV8 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.sbl] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p], [P.sig8s] ], [ [P.sig8s] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_264_95,(0,0,1):C.UVGC_356_365,(0,0,2):C.UVGC_101_4,(0,0,3):C.UVGC_356_366,(0,0,5):C.UVGC_356_367,(0,0,6):C.UVGC_356_368,(0,0,7):C.UVGC_356_369,(0,0,8):C.UVGC_356_370,(0,0,9):C.UVGC_356_371,(0,0,10):C.UVGC_356_372,(0,0,12):C.UVGC_356_373,(0,0,13):C.UVGC_356_374,(0,0,14):C.UVGC_356_375,(0,0,15):C.UVGC_356_376,(0,0,16):C.UVGC_356_377,(0,0,17):C.UVGC_356_378,(0,0,18):C.UVGC_356_379,(0,0,19):C.UVGC_356_380,(0,0,20):C.UVGC_356_381,(0,1,0):C.UVGC_263_90,(0,1,1):C.UVGC_360_417,(0,1,2):C.UVGC_360_418,(0,1,3):C.UVGC_360_419,(0,1,5):C.UVGC_360_420,(0,1,6):C.UVGC_360_421,(0,1,7):C.UVGC_360_422,(0,1,8):C.UVGC_360_423,(0,1,9):C.UVGC_360_424,(0,1,10):C.UVGC_360_425,(0,1,12):C.UVGC_360_426,(0,1,13):C.UVGC_360_427,(0,1,14):C.UVGC_360_428,(0,1,15):C.UVGC_360_429,(0,1,16):C.UVGC_360_430,(0,1,17):C.UVGC_360_431,(0,1,18):C.UVGC_360_432,(0,1,19):C.UVGC_359_415,(0,1,20):C.UVGC_359_416,(0,3,0):C.UVGC_263_90,(0,3,1):C.UVGC_359_400,(0,3,2):C.UVGC_263_92,(0,3,3):C.UVGC_359_401,(0,3,5):C.UVGC_359_402,(0,3,6):C.UVGC_359_403,(0,3,7):C.UVGC_359_404,(0,3,8):C.UVGC_359_405,(0,3,9):C.UVGC_359_406,(0,3,10):C.UVGC_359_407,(0,3,12):C.UVGC_359_408,(0,3,13):C.UVGC_359_409,(0,3,14):C.UVGC_359_410,(0,3,15):C.UVGC_359_411,(0,3,16):C.UVGC_359_412,(0,3,17):C.UVGC_359_413,(0,3,18):C.UVGC_359_414,(0,3,19):C.UVGC_359_415,(0,3,20):C.UVGC_359_416,(0,5,0):C.UVGC_264_95,(0,5,1):C.UVGC_358_384,(0,5,2):C.UVGC_358_385,(0,5,3):C.UVGC_358_386,(0,5,5):C.UVGC_358_387,(0,5,6):C.UVGC_358_388,(0,5,7):C.UVGC_358_389,(0,5,8):C.UVGC_358_390,(0,5,9):C.UVGC_358_391,(0,5,10):C.UVGC_358_392,(0,5,12):C.UVGC_358_393,(0,5,13):C.UVGC_358_394,(0,5,14):C.UVGC_358_395,(0,5,15):C.UVGC_358_396,(0,5,16):C.UVGC_358_397,(0,5,17):C.UVGC_358_398,(0,5,18):C.UVGC_358_399,(0,5,19):C.UVGC_356_380,(0,5,20):C.UVGC_356_381,(0,6,0):C.UVGC_264_95,(0,6,1):C.UVGC_357_382,(0,6,2):C.UVGC_357_383,(0,6,3):C.UVGC_356_366,(0,6,5):C.UVGC_356_367,(0,6,6):C.UVGC_356_368,(0,6,7):C.UVGC_356_369,(0,6,8):C.UVGC_356_370,(0,6,9):C.UVGC_356_371,(0,6,10):C.UVGC_356_372,(0,6,12):C.UVGC_356_373,(0,6,13):C.UVGC_356_374,(0,6,14):C.UVGC_356_375,(0,6,15):C.UVGC_356_376,(0,6,16):C.UVGC_356_377,(0,6,17):C.UVGC_356_378,(0,6,18):C.UVGC_356_379,(0,6,19):C.UVGC_356_380,(0,6,20):C.UVGC_356_381,(0,7,0):C.UVGC_263_90,(0,7,1):C.UVGC_361_433,(0,7,2):C.UVGC_361_434,(0,7,3):C.UVGC_360_419,(0,7,5):C.UVGC_360_420,(0,7,6):C.UVGC_360_421,(0,7,7):C.UVGC_360_422,(0,7,8):C.UVGC_360_423,(0,7,9):C.UVGC_360_424,(0,7,10):C.UVGC_360_425,(0,7,12):C.UVGC_360_426,(0,7,13):C.UVGC_360_427,(0,7,14):C.UVGC_360_428,(0,7,15):C.UVGC_360_429,(0,7,16):C.UVGC_360_430,(0,7,17):C.UVGC_360_431,(0,7,18):C.UVGC_360_432,(0,7,19):C.UVGC_359_415,(0,7,20):C.UVGC_359_416,(0,2,1):C.UVGC_95_959,(0,2,2):C.UVGC_263_92,(0,4,1):C.UVGC_101_3,(0,4,2):C.UVGC_101_4,(0,4,4):C.UVGC_101_5,(0,4,11):C.UVGC_101_6})

V_251 = CTVertex(name = 'V_251',
                 type = 'UV',
                 particles = [ P.g, P.g, P.g, P.g ],
                 color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,2)*f(-1,3,4)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.VVVV2, L.VVVV3, L.VVVV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur], [P.t], [P.u] ], [ [P.b], [P.c], [P.d], [P.s], [P.t], [P.u] ], [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.sbl] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p], [P.sig8s] ], [ [P.sig8s] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(2,0,3):C.UVGC_97_963,(2,0,4):C.UVGC_97_962,(0,0,3):C.UVGC_97_963,(0,0,4):C.UVGC_97_962,(4,0,3):C.UVGC_96_960,(4,0,4):C.UVGC_96_961,(3,0,3):C.UVGC_96_960,(3,0,4):C.UVGC_96_961,(8,0,3):C.UVGC_97_962,(8,0,4):C.UVGC_97_963,(6,0,2):C.UVGC_265_99,(6,0,3):C.UVGC_367_525,(6,0,4):C.UVGC_367_526,(6,0,5):C.UVGC_366_509,(6,0,7):C.UVGC_366_510,(6,0,8):C.UVGC_366_511,(6,0,9):C.UVGC_366_512,(6,0,10):C.UVGC_366_513,(6,0,11):C.UVGC_366_514,(6,0,12):C.UVGC_366_515,(6,0,14):C.UVGC_366_516,(6,0,15):C.UVGC_366_517,(6,0,16):C.UVGC_366_518,(6,0,17):C.UVGC_366_519,(6,0,18):C.UVGC_366_520,(6,0,19):C.UVGC_366_521,(6,0,20):C.UVGC_366_522,(6,0,21):C.UVGC_366_523,(6,0,22):C.UVGC_366_524,(7,0,2):C.UVGC_265_99,(7,0,3):C.UVGC_366_507,(7,0,4):C.UVGC_366_508,(7,0,5):C.UVGC_366_509,(7,0,7):C.UVGC_366_510,(7,0,8):C.UVGC_366_511,(7,0,9):C.UVGC_366_512,(7,0,10):C.UVGC_366_513,(7,0,11):C.UVGC_366_514,(7,0,12):C.UVGC_366_515,(7,0,14):C.UVGC_366_516,(7,0,15):C.UVGC_366_517,(7,0,16):C.UVGC_366_518,(7,0,17):C.UVGC_366_519,(7,0,18):C.UVGC_366_520,(7,0,19):C.UVGC_366_521,(7,0,20):C.UVGC_366_522,(7,0,21):C.UVGC_366_523,(7,0,22):C.UVGC_366_524,(5,0,3):C.UVGC_96_960,(5,0,4):C.UVGC_96_961,(1,0,3):C.UVGC_96_960,(1,0,4):C.UVGC_96_961,(11,0,3):C.UVGC_100_1,(11,0,4):C.UVGC_100_2,(10,0,3):C.UVGC_100_1,(10,0,4):C.UVGC_100_2,(9,0,3):C.UVGC_102_9,(9,0,4):C.UVGC_99_964,(2,1,3):C.UVGC_97_963,(2,1,4):C.UVGC_97_962,(0,1,3):C.UVGC_97_963,(0,1,4):C.UVGC_97_962,(4,1,3):C.UVGC_96_960,(4,1,4):C.UVGC_96_961,(3,1,3):C.UVGC_96_960,(3,1,4):C.UVGC_96_961,(8,1,2):C.UVGC_365_488,(8,1,3):C.UVGC_365_489,(8,1,4):C.UVGC_365_490,(8,1,5):C.UVGC_365_491,(8,1,7):C.UVGC_365_492,(8,1,8):C.UVGC_365_493,(8,1,9):C.UVGC_365_494,(8,1,10):C.UVGC_365_495,(8,1,11):C.UVGC_365_496,(8,1,12):C.UVGC_365_497,(8,1,14):C.UVGC_365_498,(8,1,15):C.UVGC_365_499,(8,1,16):C.UVGC_365_500,(8,1,17):C.UVGC_365_501,(8,1,18):C.UVGC_365_502,(8,1,19):C.UVGC_365_503,(8,1,20):C.UVGC_365_504,(8,1,21):C.UVGC_365_505,(8,1,22):C.UVGC_365_506,(6,1,3):C.UVGC_364_472,(6,1,4):C.UVGC_364_473,(6,1,5):C.UVGC_364_474,(6,1,7):C.UVGC_364_475,(6,1,8):C.UVGC_364_476,(6,1,9):C.UVGC_364_477,(6,1,10):C.UVGC_364_478,(6,1,11):C.UVGC_364_479,(6,1,12):C.UVGC_364_480,(6,1,14):C.UVGC_364_481,(6,1,15):C.UVGC_364_482,(6,1,16):C.UVGC_364_483,(6,1,17):C.UVGC_364_484,(6,1,18):C.UVGC_364_485,(6,1,19):C.UVGC_364_486,(6,1,20):C.UVGC_364_487,(6,1,21):C.UVGC_363_470,(6,1,22):C.UVGC_363_471,(7,1,0):C.UVGC_102_7,(7,1,3):C.UVGC_103_13,(7,1,4):C.UVGC_103_14,(7,1,13):C.UVGC_103_15,(7,1,22):C.UVGC_102_12,(5,1,3):C.UVGC_96_960,(5,1,4):C.UVGC_96_961,(1,1,3):C.UVGC_96_960,(1,1,4):C.UVGC_96_961,(11,1,3):C.UVGC_100_1,(11,1,4):C.UVGC_100_2,(10,1,3):C.UVGC_100_1,(10,1,4):C.UVGC_100_2,(9,1,3):C.UVGC_102_9,(9,1,4):C.UVGC_99_964,(0,2,3):C.UVGC_97_963,(0,2,4):C.UVGC_97_962,(2,2,3):C.UVGC_97_963,(2,2,4):C.UVGC_97_962,(5,2,3):C.UVGC_96_960,(5,2,4):C.UVGC_96_961,(1,2,3):C.UVGC_96_960,(1,2,4):C.UVGC_96_961,(7,2,3):C.UVGC_363_454,(7,2,4):C.UVGC_363_455,(7,2,5):C.UVGC_363_456,(7,2,7):C.UVGC_363_457,(7,2,8):C.UVGC_363_458,(7,2,9):C.UVGC_363_459,(7,2,10):C.UVGC_363_460,(7,2,11):C.UVGC_363_461,(7,2,12):C.UVGC_363_462,(7,2,14):C.UVGC_363_463,(7,2,15):C.UVGC_363_464,(7,2,16):C.UVGC_363_465,(7,2,17):C.UVGC_363_466,(7,2,18):C.UVGC_363_467,(7,2,19):C.UVGC_363_468,(7,2,20):C.UVGC_363_469,(7,2,21):C.UVGC_363_470,(7,2,22):C.UVGC_363_471,(4,2,3):C.UVGC_96_960,(4,2,4):C.UVGC_96_961,(3,2,3):C.UVGC_96_960,(3,2,4):C.UVGC_96_961,(8,2,2):C.UVGC_362_435,(8,2,3):C.UVGC_362_436,(8,2,4):C.UVGC_362_437,(8,2,5):C.UVGC_362_438,(8,2,7):C.UVGC_362_439,(8,2,8):C.UVGC_362_440,(8,2,9):C.UVGC_362_441,(8,2,10):C.UVGC_362_442,(8,2,11):C.UVGC_362_443,(8,2,12):C.UVGC_362_444,(8,2,14):C.UVGC_362_445,(8,2,15):C.UVGC_362_446,(8,2,16):C.UVGC_362_447,(8,2,17):C.UVGC_362_448,(8,2,18):C.UVGC_362_449,(8,2,19):C.UVGC_362_450,(8,2,20):C.UVGC_362_451,(8,2,21):C.UVGC_362_452,(8,2,22):C.UVGC_362_453,(6,2,1):C.UVGC_102_7,(6,2,3):C.UVGC_102_8,(6,2,4):C.UVGC_102_9,(6,2,6):C.UVGC_102_10,(6,2,13):C.UVGC_102_11,(6,2,22):C.UVGC_102_12,(11,2,3):C.UVGC_100_1,(11,2,4):C.UVGC_100_2,(10,2,3):C.UVGC_100_1,(10,2,4):C.UVGC_100_2,(9,2,3):C.UVGC_102_9,(9,2,4):C.UVGC_99_964})

V_252 = CTVertex(name = 'V_252',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.xglu, P.g ],
                 color = [ 'f(3,2,1)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.xglu] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.stl, P.t] ], [ [P.str, P.t] ], [ [P.sul, P.u] ], [ [P.sur, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_263_90,(0,0,7):C.UVGC_263_91,(0,0,8):C.UVGC_263_92,(0,0,1):C.UVGC_391_608,(0,0,2):C.UVGC_391_609,(0,0,3):C.UVGC_391_610,(0,0,4):C.UVGC_391_611,(0,0,5):C.UVGC_391_612,(0,0,6):C.UVGC_391_613,(0,0,9):C.UVGC_391_614,(0,0,12):C.UVGC_391_615,(0,0,13):C.UVGC_391_616,(0,0,10):C.UVGC_391_617,(0,0,11):C.UVGC_391_618,(0,0,14):C.UVGC_391_619,(0,0,15):C.UVGC_391_620,(0,0,16):C.UVGC_391_621,(0,0,17):C.UVGC_391_622,(0,1,0):C.UVGC_263_90,(0,1,7):C.UVGC_263_91,(0,1,8):C.UVGC_263_92,(0,1,1):C.UVGC_408_841,(0,1,2):C.UVGC_408_842,(0,1,3):C.UVGC_408_843,(0,1,4):C.UVGC_408_844,(0,1,5):C.UVGC_408_845,(0,1,6):C.UVGC_408_846,(0,1,9):C.UVGC_391_614,(0,1,12):C.UVGC_408_847,(0,1,13):C.UVGC_408_848,(0,1,10):C.UVGC_391_617,(0,1,11):C.UVGC_391_618,(0,1,14):C.UVGC_408_849,(0,1,15):C.UVGC_408_850,(0,1,16):C.UVGC_408_851,(0,1,17):C.UVGC_408_852})

V_253 = CTVertex(name = 'V_253',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.G__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ], [ [P.sbl, P.xglu] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_379_561,(0,0,2):C.UVGC_379_562,(0,0,3):C.UVGC_379_563,(0,0,4):C.UVGC_379_564,(0,0,5):C.UVGC_379_565,(0,0,1):C.UVGC_379_566})

V_254 = CTVertex(name = 'V_254',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.G0 ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS1 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_381_570,(0,0,1):C.UVGC_381_571,(0,0,2):C.UVGC_381_572})

V_255 = CTVertex(name = 'V_255',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.H ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS2 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_380_567,(0,0,1):C.UVGC_380_568,(0,0,2):C.UVGC_380_569})

V_256 = CTVertex(name = 'V_256',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.G__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ], [ [P.sbl, P.xglu] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_378_555,(0,0,2):C.UVGC_378_556,(0,0,3):C.UVGC_378_557,(0,0,4):C.UVGC_378_558,(0,0,5):C.UVGC_378_559,(0,0,1):C.UVGC_378_560})

# V_257 = CTVertex(name = 'V_257',
#                  type = 'UV',
#                  particles = [ P.xglu__tilde__, P.xglu, P.sig8p ],
#                  color = [ '1', 'f(3,2,1)' ],
#                  lorentz = [ L.FFS1, L.FFS3, L.FFS4 ],
#                  loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sig8p] ], [ [P.g, P.sig8p, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
#                  couplings = {(1,0,8):C.UVGC_261_85,(1,0,16):C.UVGC_261_86,(1,0,18):C.UVGC_261_87,(1,0,7):C.UVGC_261_88,(1,1,9):C.UVGC_407_809,(1,1,10):C.UVGC_407_810,(1,1,11):C.UVGC_407_811,(1,1,12):C.UVGC_407_812,(1,1,13):C.UVGC_407_813,(1,1,14):C.UVGC_407_814,(1,1,15):C.UVGC_407_815,(1,1,17):C.UVGC_407_816,(1,1,21):C.UVGC_407_817,(1,1,22):C.UVGC_407_818,(1,1,23):C.UVGC_407_819,(1,1,25):C.UVGC_407_820,(1,1,27):C.UVGC_407_821,(1,1,29):C.UVGC_407_822,(1,1,31):C.UVGC_407_823,(1,1,32):C.UVGC_407_824,(1,1,0):C.UVGC_407_825,(1,1,1):C.UVGC_407_826,(1,1,2):C.UVGC_407_827,(1,1,3):C.UVGC_407_828,(1,1,4):C.UVGC_407_829,(1,1,5):C.UVGC_407_830,(1,1,6):C.UVGC_407_831,(1,1,8):C.UVGC_407_832,(1,1,19):C.UVGC_407_833,(1,1,20):C.UVGC_407_834,(1,1,16):C.UVGC_407_835,(1,1,18):C.UVGC_407_836,(1,1,24):C.UVGC_407_837,(1,1,26):C.UVGC_407_838,(1,1,28):C.UVGC_407_839,(1,1,30):C.UVGC_407_840,(1,2,9):C.UVGC_406_778,(1,2,10):C.UVGC_406_779,(1,2,11):C.UVGC_406_780,(1,2,12):C.UVGC_406_781,(1,2,13):C.UVGC_406_782,(1,2,14):C.UVGC_406_783,(1,2,15):C.UVGC_406_784,(1,2,17):C.UVGC_406_785,(1,2,21):C.UVGC_406_786,(1,2,22):C.UVGC_406_787,(1,2,23):C.UVGC_406_788,(1,2,25):C.UVGC_406_789,(1,2,27):C.UVGC_406_790,(1,2,29):C.UVGC_406_791,(1,2,31):C.UVGC_406_792,(1,2,32):C.UVGC_406_793,(1,2,0):C.UVGC_406_794,(1,2,1):C.UVGC_406_795,(1,2,2):C.UVGC_406_796,(1,2,3):C.UVGC_406_797,(1,2,4):C.UVGC_406_798,(1,2,5):C.UVGC_406_799,(1,2,6):C.UVGC_261_88,(1,2,8):C.UVGC_406_800,(1,2,19):C.UVGC_406_801,(1,2,20):C.UVGC_406_802,(1,2,16):C.UVGC_406_803,(1,2,18):C.UVGC_406_804,(1,2,24):C.UVGC_406_805,(1,2,26):C.UVGC_406_806,(1,2,28):C.UVGC_406_807,(1,2,30):C.UVGC_406_808,(0,1,9):C.UVGC_508_908,(0,1,10):C.UVGC_508_909,(0,1,11):C.UVGC_508_910,(0,1,12):C.UVGC_508_911,(0,1,13):C.UVGC_508_912,(0,1,14):C.UVGC_508_913,(0,1,21):C.UVGC_508_914,(0,1,22):C.UVGC_508_915,(0,1,23):C.UVGC_508_916,(0,1,25):C.UVGC_508_917,(0,1,27):C.UVGC_508_918,(0,1,29):C.UVGC_508_919,(0,2,9):C.UVGC_508_908,(0,2,10):C.UVGC_508_909,(0,2,11):C.UVGC_508_910,(0,2,12):C.UVGC_508_911,(0,2,13):C.UVGC_508_912,(0,2,14):C.UVGC_508_913,(0,2,21):C.UVGC_508_914,(0,2,22):C.UVGC_508_915,(0,2,23):C.UVGC_508_916,(0,2,25):C.UVGC_508_917,(0,2,27):C.UVGC_508_918,(0,2,29):C.UVGC_508_919})

V_258 = CTVertex(name = 'V_258',
                 type = 'UV',
                 particles = [ P.g, P.sig8p, P.sig8p ],
                 color = [ 'f(1,2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sig8p] ], [ [P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_263_90,(0,0,1):C.UVGC_263_91,(0,0,2):C.UVGC_263_92,(0,0,4):C.UVGC_263_93,(0,0,3):C.UVGC_263_94,(0,1,0):C.UVGC_264_95,(0,1,1):C.UVGC_264_96,(0,1,2):C.UVGC_101_4,(0,1,4):C.UVGC_264_97,(0,1,3):C.UVGC_264_98})

V_259 = CTVertex(name = 'V_259',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sig8p, P.sig8p ],
                 color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sig8p] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_162_51,(0,0,3):C.UVGC_162_52,(2,0,1):C.UVGC_162_51,(2,0,3):C.UVGC_162_52,(6,0,0):C.UVGC_265_99,(6,0,1):C.UVGC_265_100,(6,0,2):C.UVGC_265_101,(6,0,4):C.UVGC_265_102,(6,0,3):C.UVGC_265_103,(7,0,0):C.UVGC_265_99,(7,0,1):C.UVGC_265_100,(7,0,2):C.UVGC_265_101,(7,0,4):C.UVGC_265_102,(7,0,3):C.UVGC_265_103,(5,0,1):C.UVGC_161_49,(5,0,3):C.UVGC_161_50,(1,0,1):C.UVGC_161_49,(1,0,3):C.UVGC_161_50,(4,0,1):C.UVGC_161_49,(4,0,3):C.UVGC_161_50,(3,0,1):C.UVGC_161_49,(3,0,3):C.UVGC_161_50,(10,0,1):C.UVGC_164_55,(10,0,3):C.UVGC_164_56,(9,0,1):C.UVGC_164_55,(9,0,3):C.UVGC_164_56,(8,0,1):C.UVGC_163_53,(8,0,3):C.UVGC_163_54})

# V_260 = CTVertex(name = 'V_260',
#                  type = 'UV',
#                  particles = [ P.xglu__tilde__, P.xglu, P.sig8s ],
#                  color = [ '1', 'f(3,2,1)' ],
#                  lorentz = [ L.FFS1, L.FFS2 ],
#                  loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sig8s], [P.g, P.sig8s, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
#                  couplings = {(1,1,8):C.UVGC_405_747,(1,1,9):C.UVGC_405_748,(1,1,10):C.UVGC_405_749,(1,1,11):C.UVGC_405_750,(1,1,12):C.UVGC_405_751,(1,1,13):C.UVGC_405_752,(1,1,14):C.UVGC_405_753,(1,1,16):C.UVGC_405_754,(1,1,20):C.UVGC_405_755,(1,1,21):C.UVGC_405_756,(1,1,22):C.UVGC_405_757,(1,1,24):C.UVGC_405_758,(1,1,26):C.UVGC_405_759,(1,1,28):C.UVGC_405_760,(1,1,30):C.UVGC_405_761,(1,1,31):C.UVGC_405_762,(1,1,0):C.UVGC_405_763,(1,1,1):C.UVGC_405_764,(1,1,2):C.UVGC_405_765,(1,1,3):C.UVGC_405_766,(1,1,4):C.UVGC_405_767,(1,1,5):C.UVGC_405_768,(1,1,6):C.UVGC_264_98,(1,1,7):C.UVGC_405_769,(1,1,18):C.UVGC_405_770,(1,1,19):C.UVGC_405_771,(1,1,15):C.UVGC_405_772,(1,1,17):C.UVGC_405_773,(1,1,23):C.UVGC_405_774,(1,1,25):C.UVGC_405_775,(1,1,27):C.UVGC_405_776,(1,1,29):C.UVGC_405_777,(0,0,8):C.UVGC_509_920,(0,0,9):C.UVGC_509_921,(0,0,10):C.UVGC_509_922,(0,0,11):C.UVGC_509_923,(0,0,12):C.UVGC_509_924,(0,0,13):C.UVGC_509_925,(0,0,20):C.UVGC_509_926,(0,0,21):C.UVGC_509_927,(0,0,22):C.UVGC_509_928,(0,0,24):C.UVGC_509_929,(0,0,26):C.UVGC_509_930,(0,0,28):C.UVGC_509_931})

V_261 = CTVertex(name = 'V_261',
                 type = 'UV',
                 particles = [ P.g, P.sig8s, P.sig8s ],
                 color = [ 'f(1,2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sig8s] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_263_90,(0,0,1):C.UVGC_263_91,(0,0,2):C.UVGC_263_92,(0,0,4):C.UVGC_346_267,(0,0,5):C.UVGC_346_268,(0,0,6):C.UVGC_346_269,(0,0,7):C.UVGC_346_270,(0,0,8):C.UVGC_346_271,(0,0,9):C.UVGC_346_272,(0,0,10):C.UVGC_346_273,(0,0,11):C.UVGC_346_274,(0,0,12):C.UVGC_346_275,(0,0,13):C.UVGC_346_276,(0,0,14):C.UVGC_346_277,(0,0,15):C.UVGC_346_278,(0,0,16):C.UVGC_346_279,(0,0,3):C.UVGC_263_94,(0,1,0):C.UVGC_264_95,(0,1,1):C.UVGC_264_96,(0,1,2):C.UVGC_101_4,(0,1,4):C.UVGC_347_280,(0,1,5):C.UVGC_347_281,(0,1,6):C.UVGC_347_282,(0,1,7):C.UVGC_347_283,(0,1,8):C.UVGC_347_284,(0,1,9):C.UVGC_347_285,(0,1,10):C.UVGC_347_286,(0,1,11):C.UVGC_347_287,(0,1,12):C.UVGC_347_288,(0,1,13):C.UVGC_347_289,(0,1,14):C.UVGC_347_290,(0,1,15):C.UVGC_347_291,(0,1,16):C.UVGC_347_292,(0,1,3):C.UVGC_264_98})

V_262 = CTVertex(name = 'V_262',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sig8s, P.sig8s ],
                 color = [ 'd(-1,1,3)*d(-1,2,4)', 'd(-1,1,3)*f(-1,2,4)', 'd(-1,1,4)*d(-1,2,3)', 'd(-1,1,4)*f(-1,2,3)', 'd(-1,2,3)*f(-1,1,4)', 'd(-1,2,4)*f(-1,1,3)', 'f(-1,1,3)*f(-1,2,4)', 'f(-1,1,4)*f(-1,2,3)', 'Identity(1,2)*Identity(3,4)', 'Identity(1,3)*Identity(2,4)', 'Identity(1,4)*Identity(2,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sig8s] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_162_51,(0,0,3):C.UVGC_162_52,(2,0,1):C.UVGC_162_51,(2,0,3):C.UVGC_162_52,(6,0,0):C.UVGC_265_99,(6,0,1):C.UVGC_265_100,(6,0,2):C.UVGC_265_101,(6,0,4):C.UVGC_348_293,(6,0,5):C.UVGC_348_294,(6,0,6):C.UVGC_348_295,(6,0,7):C.UVGC_348_296,(6,0,8):C.UVGC_348_297,(6,0,9):C.UVGC_348_298,(6,0,10):C.UVGC_348_299,(6,0,11):C.UVGC_348_300,(6,0,12):C.UVGC_348_301,(6,0,13):C.UVGC_348_302,(6,0,14):C.UVGC_348_303,(6,0,15):C.UVGC_348_304,(6,0,16):C.UVGC_348_305,(6,0,3):C.UVGC_265_103,(7,0,0):C.UVGC_265_99,(7,0,1):C.UVGC_265_100,(7,0,2):C.UVGC_265_101,(7,0,4):C.UVGC_348_293,(7,0,5):C.UVGC_348_294,(7,0,6):C.UVGC_348_295,(7,0,7):C.UVGC_348_296,(7,0,8):C.UVGC_348_297,(7,0,9):C.UVGC_348_298,(7,0,10):C.UVGC_348_299,(7,0,11):C.UVGC_348_300,(7,0,12):C.UVGC_348_301,(7,0,13):C.UVGC_348_302,(7,0,14):C.UVGC_348_303,(7,0,15):C.UVGC_348_304,(7,0,16):C.UVGC_348_305,(7,0,3):C.UVGC_265_103,(5,0,1):C.UVGC_161_49,(5,0,3):C.UVGC_161_50,(1,0,1):C.UVGC_161_49,(1,0,3):C.UVGC_161_50,(4,0,1):C.UVGC_161_49,(4,0,3):C.UVGC_161_50,(3,0,1):C.UVGC_161_49,(3,0,3):C.UVGC_161_50,(10,0,1):C.UVGC_164_55,(10,0,3):C.UVGC_164_56,(9,0,1):C.UVGC_164_55,(9,0,3):C.UVGC_164_56,(8,0,1):C.UVGC_163_53,(8,0,3):C.UVGC_163_54})

V_263 = CTVertex(name = 'V_263',
                 type = 'UV',
                 particles = [ P.xglu, P.d, P.sdl__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.g] ], [ [P.d, P.g, P.sdl] ], [ [P.d, P.g, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.d, P.xglu] ], [ [P.g, P.sdl] ], [ [P.g, P.sdl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdl, P.sig8s] ], [ [P.sdl, P.xglu] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,14):C.UVGC_398_680,(0,0,15):C.UVGC_398_681,(0,0,16):C.UVGC_398_682,(0,0,17):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_695,(0,0,7):C.UVGC_398_701,(0,0,8):C.UVGC_398_702,(0,0,9):C.UVGC_400_721,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,18):C.UVGC_400_722,(0,0,19):C.UVGC_400_723,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,5):C.UVGC_398_715,(0,0,6):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_264 = CTVertex(name = 'V_264',
                 type = 'UV',
                 particles = [ P.xglu, P.s, P.ssl__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.s] ], [ [P.g, P.s, P.ssl] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssl] ], [ [P.g, P.ssl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.ssl] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.s, P.xglu] ], [ [P.ssl] ], [ [P.ssl, P.xglu] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,26):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_695,(0,0,9):C.UVGC_398_703,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,25):C.UVGC_401_724,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_401_725,(0,0,22):C.UVGC_398_710,(0,0,27):C.UVGC_401_726,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_716,(0,0,10):C.UVGC_398_717})

V_265 = CTVertex(name = 'V_265',
                 type = 'UV',
                 particles = [ P.xglu, P.b, P.sbl__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.sbl] ], [ [P.b, P.g, P.xglu] ], [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.b, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sbl] ], [ [P.g, P.sbl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbl, P.sig8s] ], [ [P.sbl, P.xglu] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,16):C.UVGC_398_680,(0,0,17):C.UVGC_398_681,(0,0,18):C.UVGC_398_682,(0,0,19):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_695,(0,0,3):C.UVGC_398_696,(0,0,4):C.UVGC_398_697,(0,0,5):C.UVGC_398_698,(0,0,6):C.UVGC_398_699,(0,0,7):C.UVGC_398_700,(0,0,8):C.UVGC_398_701,(0,0,9):C.UVGC_398_702,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,14):C.UVGC_398_707,(0,0,15):C.UVGC_398_708,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,1):C.UVGC_398_715,(0,0,2):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_266 = CTVertex(name = 'V_266',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.d, P.sdr__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.g] ], [ [P.d, P.g, P.sdr] ], [ [P.d, P.g, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.d, P.xglu] ], [ [P.g, P.sdr] ], [ [P.g, P.sdr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sdr, P.sig8s] ], [ [P.sdr, P.xglu] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,15):C.UVGC_392_625,(0,0,16):C.UVGC_392_626,(0,0,17):C.UVGC_392_627,(0,0,18):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_639,(0,0,7):C.UVGC_392_645,(0,0,8):C.UVGC_392_646,(0,0,9):C.UVGC_394_665,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,19):C.UVGC_394_666,(0,0,20):C.UVGC_394_667,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,5):C.UVGC_392_659,(0,0,6):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_267 = CTVertex(name = 'V_267',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.s, P.ssr__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.s] ], [ [P.g, P.s, P.ssr] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssr] ], [ [P.g, P.ssr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.ssr] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.s, P.xglu] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.ssr, P.xglu] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,26):C.UVGC_392_631,(0,0,27):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_639,(0,0,9):C.UVGC_392_647,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,25):C.UVGC_395_668,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_395_669,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_395_670,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_660,(0,0,10):C.UVGC_392_661})

V_268 = CTVertex(name = 'V_268',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.b, P.sbr__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.sbr] ], [ [P.b, P.g, P.xglu] ], [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.b, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sbr] ], [ [P.g, P.sbr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.sbr, P.sig8s] ], [ [P.sbr, P.xglu] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,17):C.UVGC_392_625,(0,0,18):C.UVGC_392_626,(0,0,19):C.UVGC_392_627,(0,0,20):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_639,(0,0,3):C.UVGC_392_640,(0,0,4):C.UVGC_392_641,(0,0,5):C.UVGC_392_642,(0,0,6):C.UVGC_392_643,(0,0,7):C.UVGC_392_644,(0,0,8):C.UVGC_392_645,(0,0,9):C.UVGC_392_646,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,15):C.UVGC_392_651,(0,0,16):C.UVGC_392_652,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,1):C.UVGC_392_659,(0,0,2):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_269 = CTVertex(name = 'V_269',
                 type = 'UV',
                 particles = [ P.xglu, P.u, P.sul__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sul] ], [ [P.g, P.sul, P.u] ], [ [P.g, P.sul, P.xglu] ], [ [P.g, P.u] ], [ [P.g, P.u, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.sul] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.u, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,25):C.UVGC_398_687,(0,0,26):C.UVGC_398_688,(0,0,27):C.UVGC_398_689,(0,0,29):C.UVGC_398_690,(0,0,31):C.UVGC_398_691,(0,0,34):C.UVGC_398_692,(0,0,36):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_703,(0,0,9):C.UVGC_398_695,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_402_727,(0,0,22):C.UVGC_398_710,(0,0,28):C.UVGC_398_711,(0,0,30):C.UVGC_398_712,(0,0,32):C.UVGC_398_713,(0,0,33):C.UVGC_402_728,(0,0,35):C.UVGC_398_714,(0,0,37):C.UVGC_402_729,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_717,(0,0,10):C.UVGC_398_716})

V_270 = CTVertex(name = 'V_270',
                 type = 'UV',
                 particles = [ P.xglu, P.c, P.scl__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.g] ], [ [P.c, P.g, P.scl] ], [ [P.c, P.g, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.c, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.scl] ], [ [P.g, P.scl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scl, P.sig8s] ], [ [P.scl, P.xglu] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,14):C.UVGC_398_680,(0,0,15):C.UVGC_398_681,(0,0,18):C.UVGC_398_682,(0,0,19):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_695,(0,0,5):C.UVGC_398_699,(0,0,6):C.UVGC_398_700,(0,0,7):C.UVGC_399_718,(0,0,8):C.UVGC_398_701,(0,0,9):C.UVGC_398_702,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,16):C.UVGC_399_719,(0,0,17):C.UVGC_399_720,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,3):C.UVGC_398_715,(0,0,4):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_271 = CTVertex(name = 'V_271',
                 type = 'UV',
                 particles = [ P.xglu, P.t, P.stl__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.stl] ], [ [P.g, P.stl, P.t] ], [ [P.g, P.stl, P.xglu] ], [ [P.g, P.t] ], [ [P.g, P.t, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.stl] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.stl, P.xglu] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.str, P.xglu] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.t, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,25):C.UVGC_398_687,(0,0,26):C.UVGC_398_688,(0,0,27):C.UVGC_398_689,(0,0,30):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,39):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_703,(0,0,9):C.UVGC_403_730,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_403_731,(0,0,22):C.UVGC_398_710,(0,0,28):C.UVGC_398_711,(0,0,29):C.UVGC_403_732,(0,0,31):C.UVGC_398_712,(0,0,32):C.UVGC_403_733,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,38):C.UVGC_403_734,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_717,(0,0,10):C.UVGC_398_716})

V_272 = CTVertex(name = 'V_272',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.u, P.sur__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sur] ], [ [P.g, P.sur, P.u] ], [ [P.g, P.sur, P.xglu] ], [ [P.g, P.u] ], [ [P.g, P.u, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.sur] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.sur, P.xglu] ], [ [P.t] ], [ [P.u, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,25):C.UVGC_392_631,(0,0,26):C.UVGC_392_632,(0,0,27):C.UVGC_392_633,(0,0,29):C.UVGC_392_634,(0,0,31):C.UVGC_392_635,(0,0,33):C.UVGC_392_636,(0,0,36):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_647,(0,0,9):C.UVGC_392_639,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_396_671,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_392_655,(0,0,30):C.UVGC_392_656,(0,0,32):C.UVGC_392_657,(0,0,34):C.UVGC_392_658,(0,0,35):C.UVGC_396_672,(0,0,37):C.UVGC_396_673,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_661,(0,0,10):C.UVGC_392_660})

V_273 = CTVertex(name = 'V_273',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.c, P.scr__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.g] ], [ [P.c, P.g, P.scr] ], [ [P.c, P.g, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.c, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.scr] ], [ [P.g, P.scr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.scr, P.sig8s] ], [ [P.scr, P.xglu] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,15):C.UVGC_392_625,(0,0,16):C.UVGC_392_626,(0,0,19):C.UVGC_392_627,(0,0,20):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_639,(0,0,5):C.UVGC_392_643,(0,0,6):C.UVGC_392_644,(0,0,7):C.UVGC_393_662,(0,0,8):C.UVGC_392_645,(0,0,9):C.UVGC_392_646,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,17):C.UVGC_393_663,(0,0,18):C.UVGC_393_664,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,3):C.UVGC_392_659,(0,0,4):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_274 = CTVertex(name = 'V_274',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.t, P.str__tilde__ ],
                 color = [ 'T(1,2,3)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.str] ], [ [P.g, P.str, P.t] ], [ [P.g, P.str, P.xglu] ], [ [P.g, P.t] ], [ [P.g, P.t, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.str] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.stl, P.xglu] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.str, P.xglu] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.t, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,25):C.UVGC_392_631,(0,0,26):C.UVGC_392_632,(0,0,27):C.UVGC_392_633,(0,0,30):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,39):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_647,(0,0,9):C.UVGC_397_674,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_397_675,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_392_655,(0,0,29):C.UVGC_397_676,(0,0,31):C.UVGC_392_656,(0,0,32):C.UVGC_397_677,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,38):C.UVGC_397_678,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_661,(0,0,10):C.UVGC_392_660})

V_275 = CTVertex(name = 'V_275',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.d__tilde__, P.sdl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.g] ], [ [P.d, P.g, P.sdl] ], [ [P.d, P.g, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.d, P.xglu] ], [ [P.g, P.sdl] ], [ [P.g, P.sdl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdl, P.sig8s] ], [ [P.sdl, P.xglu] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,14):C.UVGC_398_680,(0,0,15):C.UVGC_398_681,(0,0,16):C.UVGC_398_682,(0,0,17):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_695,(0,0,7):C.UVGC_398_701,(0,0,8):C.UVGC_398_702,(0,0,9):C.UVGC_400_721,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,18):C.UVGC_400_722,(0,0,19):C.UVGC_400_723,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,5):C.UVGC_398_715,(0,0,6):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_276 = CTVertex(name = 'V_276',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.s__tilde__, P.ssl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.s] ], [ [P.g, P.s, P.ssl] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssl] ], [ [P.g, P.ssl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.ssl] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.s, P.xglu] ], [ [P.ssl] ], [ [P.ssl, P.xglu] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,26):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_695,(0,0,9):C.UVGC_398_703,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,25):C.UVGC_401_724,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_401_725,(0,0,22):C.UVGC_398_710,(0,0,27):C.UVGC_401_726,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_716,(0,0,10):C.UVGC_398_717})

V_277 = CTVertex(name = 'V_277',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.b__tilde__, P.sbl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.sbl] ], [ [P.b, P.g, P.xglu] ], [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.b, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sbl] ], [ [P.g, P.sbl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbl, P.sig8s] ], [ [P.sbl, P.xglu] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,16):C.UVGC_398_680,(0,0,17):C.UVGC_398_681,(0,0,18):C.UVGC_398_682,(0,0,19):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_695,(0,0,3):C.UVGC_398_696,(0,0,4):C.UVGC_398_697,(0,0,5):C.UVGC_398_698,(0,0,6):C.UVGC_398_699,(0,0,7):C.UVGC_398_700,(0,0,8):C.UVGC_398_701,(0,0,9):C.UVGC_398_702,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,14):C.UVGC_398_707,(0,0,15):C.UVGC_398_708,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,1):C.UVGC_398_715,(0,0,2):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_278 = CTVertex(name = 'V_278',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.xglu, P.sdr ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.g] ], [ [P.d, P.g, P.sdr] ], [ [P.d, P.g, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.d, P.xglu] ], [ [P.g, P.sdr] ], [ [P.g, P.sdr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sdr, P.sig8s] ], [ [P.sdr, P.xglu] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,15):C.UVGC_392_625,(0,0,16):C.UVGC_392_626,(0,0,17):C.UVGC_392_627,(0,0,18):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_639,(0,0,7):C.UVGC_392_645,(0,0,8):C.UVGC_392_646,(0,0,9):C.UVGC_394_665,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,19):C.UVGC_394_666,(0,0,20):C.UVGC_394_667,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,5):C.UVGC_392_659,(0,0,6):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_279 = CTVertex(name = 'V_279',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.xglu, P.ssr ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.s] ], [ [P.g, P.s, P.ssr] ], [ [P.g, P.s, P.xglu] ], [ [P.g, P.ssr] ], [ [P.g, P.ssr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.ssr] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.s, P.xglu] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.ssr, P.xglu] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,26):C.UVGC_392_631,(0,0,27):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_639,(0,0,9):C.UVGC_392_647,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,25):C.UVGC_395_668,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_395_669,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_395_670,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_660,(0,0,10):C.UVGC_392_661})

V_280 = CTVertex(name = 'V_280',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.xglu, P.sbr ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.sbr] ], [ [P.b, P.g, P.xglu] ], [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.b, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sbr] ], [ [P.g, P.sbr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.sbr, P.sig8s] ], [ [P.sbr, P.xglu] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,17):C.UVGC_392_625,(0,0,18):C.UVGC_392_626,(0,0,19):C.UVGC_392_627,(0,0,20):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_639,(0,0,3):C.UVGC_392_640,(0,0,4):C.UVGC_392_641,(0,0,5):C.UVGC_392_642,(0,0,6):C.UVGC_392_643,(0,0,7):C.UVGC_392_644,(0,0,8):C.UVGC_392_645,(0,0,9):C.UVGC_392_646,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,15):C.UVGC_392_651,(0,0,16):C.UVGC_392_652,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,1):C.UVGC_392_659,(0,0,2):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_281 = CTVertex(name = 'V_281',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.u__tilde__, P.sul ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sul] ], [ [P.g, P.sul, P.u] ], [ [P.g, P.sul, P.xglu] ], [ [P.g, P.u] ], [ [P.g, P.u, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.sul] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.u, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,25):C.UVGC_398_687,(0,0,26):C.UVGC_398_688,(0,0,27):C.UVGC_398_689,(0,0,29):C.UVGC_398_690,(0,0,31):C.UVGC_398_691,(0,0,34):C.UVGC_398_692,(0,0,36):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_703,(0,0,9):C.UVGC_398_695,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_402_727,(0,0,22):C.UVGC_398_710,(0,0,28):C.UVGC_398_711,(0,0,30):C.UVGC_398_712,(0,0,32):C.UVGC_398_713,(0,0,33):C.UVGC_402_728,(0,0,35):C.UVGC_398_714,(0,0,37):C.UVGC_402_729,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_717,(0,0,10):C.UVGC_398_716})

V_282 = CTVertex(name = 'V_282',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.c__tilde__, P.scl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.g] ], [ [P.c, P.g, P.scl] ], [ [P.c, P.g, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.c, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.scl] ], [ [P.g, P.scl, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scl, P.sig8s] ], [ [P.scl, P.xglu] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_398_679,(0,0,14):C.UVGC_398_680,(0,0,15):C.UVGC_398_681,(0,0,18):C.UVGC_398_682,(0,0,19):C.UVGC_398_683,(0,0,20):C.UVGC_398_684,(0,0,21):C.UVGC_398_685,(0,0,23):C.UVGC_398_686,(0,0,27):C.UVGC_398_687,(0,0,28):C.UVGC_398_688,(0,0,29):C.UVGC_398_689,(0,0,31):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,38):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_695,(0,0,5):C.UVGC_398_699,(0,0,6):C.UVGC_398_700,(0,0,7):C.UVGC_399_718,(0,0,8):C.UVGC_398_701,(0,0,9):C.UVGC_398_702,(0,0,10):C.UVGC_398_703,(0,0,12):C.UVGC_398_704,(0,0,25):C.UVGC_398_705,(0,0,26):C.UVGC_398_706,(0,0,16):C.UVGC_399_719,(0,0,17):C.UVGC_399_720,(0,0,22):C.UVGC_398_709,(0,0,24):C.UVGC_398_710,(0,0,30):C.UVGC_398_711,(0,0,32):C.UVGC_398_712,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,3):C.UVGC_398_715,(0,0,4):C.UVGC_398_716,(0,0,11):C.UVGC_398_717})

V_283 = CTVertex(name = 'V_283',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.t__tilde__, P.stl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.FFS3 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.stl] ], [ [P.g, P.stl, P.t] ], [ [P.g, P.stl, P.xglu] ], [ [P.g, P.t] ], [ [P.g, P.t, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.stl] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.stl, P.xglu] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.str, P.xglu] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.t, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_398_679,(0,0,13):C.UVGC_398_680,(0,0,14):C.UVGC_398_681,(0,0,15):C.UVGC_398_682,(0,0,16):C.UVGC_398_683,(0,0,17):C.UVGC_398_684,(0,0,18):C.UVGC_398_685,(0,0,20):C.UVGC_398_686,(0,0,25):C.UVGC_398_687,(0,0,26):C.UVGC_398_688,(0,0,27):C.UVGC_398_689,(0,0,30):C.UVGC_398_690,(0,0,33):C.UVGC_398_691,(0,0,35):C.UVGC_398_692,(0,0,37):C.UVGC_398_693,(0,0,39):C.UVGC_398_694,(0,0,0):C.UVGC_398_696,(0,0,1):C.UVGC_398_697,(0,0,2):C.UVGC_398_699,(0,0,3):C.UVGC_398_700,(0,0,4):C.UVGC_398_701,(0,0,5):C.UVGC_398_702,(0,0,6):C.UVGC_398_703,(0,0,9):C.UVGC_403_730,(0,0,11):C.UVGC_398_704,(0,0,23):C.UVGC_398_705,(0,0,24):C.UVGC_398_706,(0,0,19):C.UVGC_398_709,(0,0,21):C.UVGC_403_731,(0,0,22):C.UVGC_398_710,(0,0,28):C.UVGC_398_711,(0,0,29):C.UVGC_403_732,(0,0,31):C.UVGC_398_712,(0,0,32):C.UVGC_403_733,(0,0,34):C.UVGC_398_713,(0,0,36):C.UVGC_398_714,(0,0,38):C.UVGC_403_734,(0,0,7):C.UVGC_398_715,(0,0,8):C.UVGC_398_717,(0,0,10):C.UVGC_398_716})

V_284 = CTVertex(name = 'V_284',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.xglu, P.sur ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.sur] ], [ [P.g, P.sur, P.u] ], [ [P.g, P.sur, P.xglu] ], [ [P.g, P.u] ], [ [P.g, P.u, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.sur] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.sur, P.xglu] ], [ [P.t] ], [ [P.u, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,25):C.UVGC_392_631,(0,0,26):C.UVGC_392_632,(0,0,27):C.UVGC_392_633,(0,0,29):C.UVGC_392_634,(0,0,31):C.UVGC_392_635,(0,0,33):C.UVGC_392_636,(0,0,36):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_647,(0,0,9):C.UVGC_392_639,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_396_671,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_392_655,(0,0,30):C.UVGC_392_656,(0,0,32):C.UVGC_392_657,(0,0,34):C.UVGC_392_658,(0,0,35):C.UVGC_396_672,(0,0,37):C.UVGC_396_673,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_661,(0,0,10):C.UVGC_392_660})

V_285 = CTVertex(name = 'V_285',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.xglu, P.scr ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.g] ], [ [P.c, P.g, P.scr] ], [ [P.c, P.g, P.xglu] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.c, P.xglu] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.scr] ], [ [P.g, P.scr, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.scr, P.sig8s] ], [ [P.scr, P.xglu] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,13):C.UVGC_392_623,(0,0,14):C.UVGC_392_624,(0,0,15):C.UVGC_392_625,(0,0,16):C.UVGC_392_626,(0,0,19):C.UVGC_392_627,(0,0,20):C.UVGC_392_628,(0,0,21):C.UVGC_392_629,(0,0,23):C.UVGC_392_630,(0,0,27):C.UVGC_392_631,(0,0,28):C.UVGC_392_632,(0,0,29):C.UVGC_392_633,(0,0,31):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,38):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_639,(0,0,5):C.UVGC_392_643,(0,0,6):C.UVGC_392_644,(0,0,7):C.UVGC_393_662,(0,0,8):C.UVGC_392_645,(0,0,9):C.UVGC_392_646,(0,0,10):C.UVGC_392_647,(0,0,12):C.UVGC_392_648,(0,0,25):C.UVGC_392_649,(0,0,26):C.UVGC_392_650,(0,0,17):C.UVGC_393_663,(0,0,18):C.UVGC_393_664,(0,0,22):C.UVGC_392_653,(0,0,24):C.UVGC_392_654,(0,0,30):C.UVGC_392_655,(0,0,32):C.UVGC_392_656,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,3):C.UVGC_392_659,(0,0,4):C.UVGC_392_660,(0,0,11):C.UVGC_392_661})

V_286 = CTVertex(name = 'V_286',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.xglu, P.str ],
                 color = [ 'T(2,3,1)' ],
                 lorentz = [ L.FFS4 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.str] ], [ [P.g, P.str, P.t] ], [ [P.g, P.str, P.xglu] ], [ [P.g, P.t] ], [ [P.g, P.t, P.xglu] ], [ [P.g, P.xglu] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8p, P.xglu] ], [ [P.sig8s] ], [ [P.sig8s, P.str] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.stl, P.t] ], [ [P.stl, P.xglu] ], [ [P.str] ], [ [P.str, P.t] ], [ [P.str, P.xglu] ], [ [P.sul] ], [ [P.sul, P.u] ], [ [P.sur] ], [ [P.sur, P.u] ], [ [P.t] ], [ [P.t, P.xglu] ], [ [P.xglu] ] ],
                 couplings = {(0,0,12):C.UVGC_392_623,(0,0,13):C.UVGC_392_624,(0,0,14):C.UVGC_392_625,(0,0,15):C.UVGC_392_626,(0,0,16):C.UVGC_392_627,(0,0,17):C.UVGC_392_628,(0,0,18):C.UVGC_392_629,(0,0,20):C.UVGC_392_630,(0,0,25):C.UVGC_392_631,(0,0,26):C.UVGC_392_632,(0,0,27):C.UVGC_392_633,(0,0,30):C.UVGC_392_634,(0,0,33):C.UVGC_392_635,(0,0,35):C.UVGC_392_636,(0,0,37):C.UVGC_392_637,(0,0,39):C.UVGC_392_638,(0,0,0):C.UVGC_392_640,(0,0,1):C.UVGC_392_641,(0,0,2):C.UVGC_392_643,(0,0,3):C.UVGC_392_644,(0,0,4):C.UVGC_392_645,(0,0,5):C.UVGC_392_646,(0,0,6):C.UVGC_392_647,(0,0,9):C.UVGC_397_674,(0,0,11):C.UVGC_392_648,(0,0,23):C.UVGC_392_649,(0,0,24):C.UVGC_392_650,(0,0,19):C.UVGC_392_653,(0,0,21):C.UVGC_397_675,(0,0,22):C.UVGC_392_654,(0,0,28):C.UVGC_392_655,(0,0,29):C.UVGC_397_676,(0,0,31):C.UVGC_392_656,(0,0,32):C.UVGC_397_677,(0,0,34):C.UVGC_392_657,(0,0,36):C.UVGC_392_658,(0,0,38):C.UVGC_397_678,(0,0,7):C.UVGC_392_659,(0,0,8):C.UVGC_392_661,(0,0,10):C.UVGC_392_660})

V_287 = CTVertex(name = 'V_287',
                 type = 'UV',
                 particles = [ P.sdl__tilde__, P.sdl, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdl] ], [ [P.g, P.sdl, P.sig8s] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.sdl] ] ],
                 couplings = {(0,0,3):C.UVGC_235_74,(0,0,4):C.UVGC_235_73,(0,0,0):C.UVGC_235_75,(0,0,1):C.UVGC_235_76,(0,0,2):C.UVGC_235_77})

V_288 = CTVertex(name = 'V_288',
                 type = 'UV',
                 particles = [ P.sig8s, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.ssl] ], [ [P.g, P.ssl] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.s, P.xglu] ], [ [P.ssl] ] ],
                 couplings = {(0,0,2):C.UVGC_235_74,(0,0,4):C.UVGC_235_73,(0,0,1):C.UVGC_235_76,(0,0,3):C.UVGC_235_75,(0,0,0):C.UVGC_235_77})

V_289 = CTVertex(name = 'V_289',
                 type = 'UV',
                 particles = [ P.sbl__tilde__, P.sbl, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbl] ], [ [P.g, P.sbl, P.sig8s] ], [ [P.sbl] ], [ [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ] ],
                 couplings = {(0,0,3):C.UVGC_235_73,(0,0,4):C.UVGC_235_74,(0,0,0):C.UVGC_235_75,(0,0,1):C.UVGC_235_76,(0,0,2):C.UVGC_235_77})

V_290 = CTVertex(name = 'V_290',
                 type = 'UV',
                 particles = [ P.sdr__tilde__, P.sdr, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdr] ], [ [P.g, P.sdr, P.sig8s] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.sdr] ] ],
                 couplings = {(0,0,3):C.UVGC_236_78,(0,0,4):C.UVGC_236_79,(0,0,0):C.UVGC_236_80,(0,0,1):C.UVGC_236_81,(0,0,2):C.UVGC_236_82})

V_291 = CTVertex(name = 'V_291',
                 type = 'UV',
                 particles = [ P.sig8s, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.ssr] ], [ [P.g, P.ssr] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.s, P.xglu] ], [ [P.ssr] ] ],
                 couplings = {(0,0,2):C.UVGC_236_78,(0,0,4):C.UVGC_236_79,(0,0,1):C.UVGC_236_81,(0,0,3):C.UVGC_236_80,(0,0,0):C.UVGC_236_82})

V_292 = CTVertex(name = 'V_292',
                 type = 'UV',
                 particles = [ P.sbr__tilde__, P.sbr, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbr] ], [ [P.g, P.sbr, P.sig8s] ], [ [P.sbl], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.sbr] ] ],
                 couplings = {(0,0,3):C.UVGC_236_78,(0,0,4):C.UVGC_236_79,(0,0,0):C.UVGC_236_80,(0,0,1):C.UVGC_236_81,(0,0,2):C.UVGC_236_82})

V_293 = CTVertex(name = 'V_293',
                 type = 'UV',
                 particles = [ P.sig8s, P.sul__tilde__, P.sul ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.sul] ], [ [P.g, P.sul] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sur] ], [ [P.sul] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_235_74,(0,0,3):C.UVGC_235_73,(0,0,1):C.UVGC_235_76,(0,0,4):C.UVGC_235_75,(0,0,0):C.UVGC_235_77})

V_294 = CTVertex(name = 'V_294',
                 type = 'UV',
                 particles = [ P.scl__tilde__, P.scl, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scl] ], [ [P.g, P.scl, P.sig8s] ], [ [P.sbl], [P.sbr], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.scl] ] ],
                 couplings = {(0,0,3):C.UVGC_235_74,(0,0,4):C.UVGC_235_73,(0,0,0):C.UVGC_235_75,(0,0,1):C.UVGC_235_76,(0,0,2):C.UVGC_235_77})

V_295 = CTVertex(name = 'V_295',
                 type = 'UV',
                 particles = [ P.sig8s, P.stl__tilde__, P.stl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.stl] ], [ [P.g, P.stl] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.str], [P.sul], [P.sur] ], [ [P.stl] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_235_74,(0,0,3):C.UVGC_235_73,(0,0,1):C.UVGC_235_76,(0,0,4):C.UVGC_235_75,(0,0,0):C.UVGC_235_77})

V_296 = CTVertex(name = 'V_296',
                 type = 'UV',
                 particles = [ P.sig8s, P.sur__tilde__, P.sur ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.sur] ], [ [P.g, P.sur] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul] ], [ [P.sur] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_236_78,(0,0,3):C.UVGC_236_79,(0,0,1):C.UVGC_236_81,(0,0,4):C.UVGC_236_80,(0,0,0):C.UVGC_236_82})

V_297 = CTVertex(name = 'V_297',
                 type = 'UV',
                 particles = [ P.scr__tilde__, P.scr, P.sig8s ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scr] ], [ [P.g, P.scr, P.sig8s] ], [ [P.sbl], [P.sbr], [P.scl], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ], [ [P.scr] ] ],
                 couplings = {(0,0,3):C.UVGC_236_78,(0,0,4):C.UVGC_236_79,(0,0,0):C.UVGC_236_80,(0,0,1):C.UVGC_236_81,(0,0,2):C.UVGC_236_82})

V_298 = CTVertex(name = 'V_298',
                 type = 'UV',
                 particles = [ P.sig8s, P.str__tilde__, P.str ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.g, P.sig8s, P.str] ], [ [P.g, P.str] ], [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.sul], [P.sur] ], [ [P.str] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_236_78,(0,0,3):C.UVGC_236_79,(0,0,1):C.UVGC_236_81,(0,0,4):C.UVGC_236_80,(0,0,0):C.UVGC_236_82})

V_299 = CTVertex(name = 'V_299',
                 type = 'UV',
                 particles = [ P.g, P.sul__tilde__, P.sul ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sul] ], [ [P.sig8s, P.sul] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,4):C.UVGC_338_242,(0,0,5):C.UVGC_338_243})

V_300 = CTVertex(name = 'V_300',
                 type = 'UV',
                 particles = [ P.g, P.scl__tilde__, P.scl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.scl] ], [ [P.scl, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_288_152,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_288_153})

V_301 = CTVertex(name = 'V_301',
                 type = 'UV',
                 particles = [ P.g, P.stl__tilde__, P.stl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.stl] ], [ [P.sig8s, P.stl] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,4):C.UVGC_383_575,(0,0,5):C.UVGC_383_576})

V_302 = CTVertex(name = 'V_302',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sul] ], [ [P.sig8s, P.sul] ], [ [P.u, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,4):C.UVGC_339_244,(2,0,5):C.UVGC_339_245,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,4):C.UVGC_339_244,(1,0,5):C.UVGC_339_245,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_303 = CTVertex(name = 'V_303',
                 type = 'UV',
                 particles = [ P.g, P.g, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.scl] ], [ [P.scl, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_289_154,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_289_155,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_289_154,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_289_155,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_304 = CTVertex(name = 'V_304',
                 type = 'UV',
                 particles = [ P.g, P.g, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.stl] ], [ [P.sig8s, P.stl] ], [ [P.t, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,4):C.UVGC_384_577,(2,0,5):C.UVGC_384_578,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,4):C.UVGC_384_577,(1,0,5):C.UVGC_384_578,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_305 = CTVertex(name = 'V_305',
                 type = 'UV',
                 particles = [ P.g, P.sur__tilde__, P.sur ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sur] ], [ [P.sig8s, P.sur] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,4):C.UVGC_351_323,(0,0,5):C.UVGC_351_324})

V_306 = CTVertex(name = 'V_306',
                 type = 'UV',
                 particles = [ P.g, P.scr__tilde__, P.scr ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.scr] ], [ [P.scr, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_296_166,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_296_167})

V_307 = CTVertex(name = 'V_307',
                 type = 'UV',
                 particles = [ P.g, P.str__tilde__, P.str ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.str] ], [ [P.sig8s, P.str] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,4):C.UVGC_387_585,(0,0,5):C.UVGC_387_586})

V_308 = CTVertex(name = 'V_308',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sur] ], [ [P.sig8s, P.sur] ], [ [P.u, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,4):C.UVGC_352_325,(2,0,5):C.UVGC_352_326,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,4):C.UVGC_352_325,(1,0,5):C.UVGC_352_326,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_309 = CTVertex(name = 'V_309',
                 type = 'UV',
                 particles = [ P.g, P.g, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.scr] ], [ [P.scr, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_297_168,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_297_169,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_297_168,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_297_169,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_310 = CTVertex(name = 'V_310',
                 type = 'UV',
                 particles = [ P.g, P.g, P.str__tilde__, P.str ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.str] ], [ [P.sig8s, P.str] ], [ [P.t, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,4):C.UVGC_388_587,(2,0,5):C.UVGC_388_588,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,4):C.UVGC_388_587,(1,0,5):C.UVGC_388_588,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_311 = CTVertex(name = 'V_311',
                 type = 'UV',
                 particles = [ P.g, P.sdl__tilde__, P.sdl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sdl] ], [ [P.sdl, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_304_180,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_304_181})

V_312 = CTVertex(name = 'V_312',
                 type = 'UV',
                 particles = [ P.g, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.ssl] ], [ [P.sig8s, P.ssl] ], [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,5):C.UVGC_321_212,(0,0,4):C.UVGC_321_213})

V_313 = CTVertex(name = 'V_313',
                 type = 'UV',
                 particles = [ P.g, P.sbl__tilde__, P.sbl ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sbl] ], [ [P.sbl, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_272_122,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_272_123})

V_314 = CTVertex(name = 'V_314',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sdl] ], [ [P.sdl, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_305_182,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_305_183,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_305_182,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_305_183,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_315 = CTVertex(name = 'V_315',
                 type = 'UV',
                 particles = [ P.g, P.g, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.ssl] ], [ [P.sig8s, P.ssl] ], [ [P.s, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,5):C.UVGC_322_214,(2,0,4):C.UVGC_322_215,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,5):C.UVGC_322_214,(1,0,4):C.UVGC_322_215,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_316 = CTVertex(name = 'V_316',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sbl] ], [ [P.sbl, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_273_125,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_273_127,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_273_125,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_273_127,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_317 = CTVertex(name = 'V_317',
                 type = 'UV',
                 particles = [ P.g, P.sdr__tilde__, P.sdr ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sdr] ], [ [P.sdr, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_312_194,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_312_195})

V_318 = CTVertex(name = 'V_318',
                 type = 'UV',
                 particles = [ P.g, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.ssr] ], [ [P.sig8s, P.ssr] ], [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,1):C.UVGC_272_120,(0,0,2):C.UVGC_272_121,(0,0,3):C.UVGC_261_88,(0,0,5):C.UVGC_329_226,(0,0,4):C.UVGC_329_227})

V_319 = CTVertex(name = 'V_319',
                 type = 'UV',
                 particles = [ P.g, P.sbr__tilde__, P.sbr ],
                 color = [ 'T(1,3,2)' ],
                 lorentz = [ L.VSS2 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sbr] ], [ [P.sbr, P.sig8s] ] ],
                 couplings = {(0,0,0):C.UVGC_272_119,(0,0,2):C.UVGC_272_120,(0,0,3):C.UVGC_272_121,(0,0,1):C.UVGC_280_138,(0,0,4):C.UVGC_261_88,(0,0,5):C.UVGC_280_139})

V_320 = CTVertex(name = 'V_320',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sdr] ], [ [P.sdr, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_313_196,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_313_197,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_313_196,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_313_197,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_321 = CTVertex(name = 'V_321',
                 type = 'UV',
                 particles = [ P.g, P.g, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.ssr] ], [ [P.sig8s, P.ssr] ], [ [P.s, P.xglu] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,1):C.UVGC_273_124,(2,0,2):C.UVGC_265_101,(2,0,3):C.UVGC_273_126,(2,0,5):C.UVGC_330_228,(2,0,4):C.UVGC_330_229,(1,0,0):C.UVGC_265_99,(1,0,1):C.UVGC_273_124,(1,0,2):C.UVGC_265_101,(1,0,3):C.UVGC_273_126,(1,0,5):C.UVGC_330_228,(1,0,4):C.UVGC_330_229,(0,0,1):C.UVGC_155_47,(0,0,3):C.UVGC_155_48})

V_322 = CTVertex(name = 'V_322',
                 type = 'UV',
                 particles = [ P.g, P.g, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(1,2)*Identity(3,4)', 'T(1,-1,3)*T(2,4,-1)', 'T(1,4,-1)*T(2,-1,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.xglu] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.sbr] ], [ [P.sbr, P.sig8s] ] ],
                 couplings = {(2,0,0):C.UVGC_265_99,(2,0,2):C.UVGC_273_124,(2,0,3):C.UVGC_265_101,(2,0,1):C.UVGC_281_140,(2,0,4):C.UVGC_273_126,(2,0,5):C.UVGC_281_141,(1,0,0):C.UVGC_265_99,(1,0,2):C.UVGC_273_124,(1,0,3):C.UVGC_265_101,(1,0,1):C.UVGC_281_140,(1,0,4):C.UVGC_273_126,(1,0,5):C.UVGC_281_141,(0,0,2):C.UVGC_155_47,(0,0,4):C.UVGC_155_48})

V_323 = CTVertex(name = 'V_323',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20,(0,1,1):C.UVGC_333_235,(0,2,0):C.UVGC_108_20,(0,2,2):C.UVGC_342_251})

V_324 = CTVertex(name = 'V_324',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.scl, P.xglu] ], [ [P.scr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20,(0,1,1):C.UVGC_284_147,(0,2,0):C.UVGC_108_20,(0,2,2):C.UVGC_292_161})

V_325 = CTVertex(name = 'V_325',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_369_530,(0,1,1):C.UVGC_369_531,(0,1,2):C.UVGC_369_532,(0,2,0):C.UVGC_369_530,(0,2,1):C.UVGC_373_541,(0,2,2):C.UVGC_373_542})

V_326 = CTVertex(name = 'V_326',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur, P.xglu] ] ],
                 couplings = {(0,0,3):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,1):C.UVGC_269_112,(0,1,2):C.UVGC_269_113,(0,1,3):C.UVGC_269_114,(0,1,4):C.UVGC_334_236,(0,2,0):C.UVGC_269_111,(0,2,1):C.UVGC_269_112,(0,2,2):C.UVGC_269_113,(0,2,3):C.UVGC_269_114,(0,2,5):C.UVGC_343_252})

V_327 = CTVertex(name = 'V_327',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.c, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.scl, P.xglu] ], [ [P.scr, P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,2):C.UVGC_269_112,(0,1,3):C.UVGC_269_113,(0,1,1):C.UVGC_269_114,(0,1,4):C.UVGC_285_148,(0,2,0):C.UVGC_269_111,(0,2,2):C.UVGC_269_112,(0,2,3):C.UVGC_269_113,(0,2,1):C.UVGC_269_114,(0,2,5):C.UVGC_293_162})

V_328 = CTVertex(name = 'V_328',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,3):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,1):C.UVGC_269_112,(0,1,2):C.UVGC_269_113,(0,1,3):C.UVGC_370_533,(0,1,4):C.UVGC_370_534,(0,1,5):C.UVGC_370_535,(0,2,0):C.UVGC_269_111,(0,2,1):C.UVGC_269_112,(0,2,2):C.UVGC_269_113,(0,2,3):C.UVGC_370_533,(0,2,4):C.UVGC_374_543,(0,2,5):C.UVGC_374_544})

V_329 = CTVertex(name = 'V_329',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.u, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ], [ [P.sdl, P.xglu] ], [ [P.sul, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_335_237,(0,0,3):C.UVGC_335_238,(0,0,1):C.UVGC_318_208})

V_330 = CTVertex(name = 'V_330',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.c, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ], [ [P.scl, P.xglu] ], [ [P.ssl, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_318_206,(0,0,3):C.UVGC_318_207,(0,0,1):C.UVGC_318_208})

V_331 = CTVertex(name = 'V_331',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.t, P.W__minus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ], [ [P.sbl, P.xglu] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_375_545,(0,0,3):C.UVGC_375_546,(0,0,4):C.UVGC_375_547,(0,0,5):C.UVGC_375_548,(0,0,1):C.UVGC_318_208})

V_332 = CTVertex(name = 'V_332',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.sul, P.xglu] ], [ [P.sur, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_336_239,(0,1,1):C.UVGC_344_253})

V_333 = CTVertex(name = 'V_333',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.scl, P.xglu] ], [ [P.scr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_286_149,(0,1,1):C.UVGC_294_163})

V_334 = CTVertex(name = 'V_334',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_376_549,(0,0,1):C.UVGC_376_550,(0,0,2):C.UVGC_376_551,(0,1,0):C.UVGC_377_552,(0,1,1):C.UVGC_377_553,(0,1,2):C.UVGC_377_554})

V_335 = CTVertex(name = 'V_335',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.sdl, P.xglu] ], [ [P.sdr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_105_17,(0,1,0):C.UVGC_268_109,(0,1,1):C.UVGC_300_175,(0,2,0):C.UVGC_268_109,(0,2,2):C.UVGC_308_189})

V_336 = CTVertex(name = 'V_336',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.ssl, P.xglu] ], [ [P.ssr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_105_17,(0,1,0):C.UVGC_268_109,(0,1,1):C.UVGC_316_203,(0,2,0):C.UVGC_268_109,(0,2,2):C.UVGC_325_221})

V_337 = CTVertex(name = 'V_337',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.sbl, P.xglu] ], [ [P.sbr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_105_17,(0,1,0):C.UVGC_268_109,(0,1,1):C.UVGC_268_110,(0,2,0):C.UVGC_268_109,(0,2,2):C.UVGC_276_133})

V_338 = CTVertex(name = 'V_338',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.d, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.sdl, P.xglu] ], [ [P.sdr, P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,2):C.UVGC_269_112,(0,1,3):C.UVGC_269_113,(0,1,1):C.UVGC_269_114,(0,1,4):C.UVGC_301_176,(0,2,0):C.UVGC_269_111,(0,2,2):C.UVGC_269_112,(0,2,3):C.UVGC_269_113,(0,2,1):C.UVGC_269_114,(0,2,5):C.UVGC_309_190})

V_339 = CTVertex(name = 'V_339',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.g] ], [ [P.ghG] ], [ [P.g, P.s] ], [ [P.ssl, P.xglu] ], [ [P.ssr, P.xglu] ] ],
                 couplings = {(0,0,3):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,1):C.UVGC_269_112,(0,1,2):C.UVGC_269_113,(0,1,3):C.UVGC_269_114,(0,1,4):C.UVGC_317_204,(0,2,0):C.UVGC_269_111,(0,2,1):C.UVGC_269_112,(0,2,2):C.UVGC_269_113,(0,2,3):C.UVGC_269_114,(0,2,5):C.UVGC_326_222})

V_340 = CTVertex(name = 'V_340',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.g ],
                 color = [ 'T(3,2,1)' ],
                 lorentz = [ L.FFV1, L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.b], [P.c], [P.d], [P.s], [P.u] ], [ [P.b, P.g] ], [ [P.g] ], [ [P.ghG] ], [ [P.sbl, P.xglu] ], [ [P.sbr, P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_106_18,(0,1,0):C.UVGC_269_111,(0,1,2):C.UVGC_269_112,(0,1,3):C.UVGC_269_113,(0,1,1):C.UVGC_269_114,(0,1,4):C.UVGC_269_115,(0,2,0):C.UVGC_269_111,(0,2,2):C.UVGC_269_112,(0,2,3):C.UVGC_269_113,(0,2,1):C.UVGC_269_114,(0,2,5):C.UVGC_277_134})

V_341 = CTVertex(name = 'V_341',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.d, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.d, P.g], [P.g, P.u] ], [ [P.d, P.g, P.u] ], [ [P.sdl, P.xglu] ], [ [P.sul, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_335_237,(0,0,3):C.UVGC_335_238,(0,0,1):C.UVGC_318_208})

V_342 = CTVertex(name = 'V_342',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.s, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.c, P.g], [P.g, P.s] ], [ [P.c, P.g, P.s] ], [ [P.scl, P.xglu] ], [ [P.ssl, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_318_206,(0,0,3):C.UVGC_318_207,(0,0,1):C.UVGC_318_208})

V_343 = CTVertex(name = 'V_343',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.b, P.W__plus__ ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.b, P.g, P.t] ], [ [P.g, P.t] ], [ [P.sbl, P.xglu] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_318_205,(0,0,2):C.UVGC_375_545,(0,0,3):C.UVGC_375_546,(0,0,4):C.UVGC_375_547,(0,0,5):C.UVGC_375_548,(0,0,1):C.UVGC_318_208})

V_344 = CTVertex(name = 'V_344',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.sdl, P.xglu] ], [ [P.sdr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_302_177,(0,1,1):C.UVGC_310_191})

V_345 = CTVertex(name = 'V_345',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.ssl, P.xglu] ], [ [P.ssr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_319_209,(0,1,1):C.UVGC_327_223})

V_346 = CTVertex(name = 'V_346',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3, L.FFV4 ],
                 loop_particles = [ [ [P.sbl, P.xglu] ], [ [P.sbr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_270_116,(0,1,1):C.UVGC_278_135})

V_347 = CTVertex(name = 'V_347',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.xglu ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4, L.FF5 ],
                 loop_particles = [ [ [P.b, P.sbl] ], [ [P.b, P.sbr] ], [ [P.c, P.scl] ], [ [P.c, P.scr] ], [ [P.d, P.sdl] ], [ [P.d, P.sdr] ], [ [P.g, P.xglu] ], [ [P.sig8p, P.xglu] ], [ [P.sig8p, P.xglu], [P.sig8s, P.xglu] ], [ [P.sig8s, P.xglu] ], [ [P.s, P.ssl] ], [ [P.s, P.ssr] ], [ [P.stl, P.t] ], [ [P.str, P.t] ], [ [P.sul, P.u] ], [ [P.sur, P.u] ] ],
                 couplings = {(0,1,0):C.UVGC_409_853,(0,1,1):C.UVGC_409_854,(0,1,2):C.UVGC_409_855,(0,1,3):C.UVGC_409_856,(0,1,4):C.UVGC_409_857,(0,1,5):C.UVGC_409_858,(0,1,6):C.UVGC_409_859,(0,1,10):C.UVGC_409_860,(0,1,11):C.UVGC_409_861,(0,1,7):C.UVGC_409_862,(0,1,9):C.UVGC_409_863,(0,1,12):C.UVGC_409_864,(0,1,13):C.UVGC_409_865,(0,1,14):C.UVGC_409_866,(0,1,15):C.UVGC_409_867,(0,3,0):C.UVGC_409_853,(0,3,1):C.UVGC_409_854,(0,3,2):C.UVGC_409_855,(0,3,3):C.UVGC_409_856,(0,3,4):C.UVGC_409_857,(0,3,5):C.UVGC_409_858,(0,3,6):C.UVGC_409_859,(0,3,10):C.UVGC_409_860,(0,3,11):C.UVGC_409_861,(0,3,7):C.UVGC_409_862,(0,3,9):C.UVGC_409_863,(0,3,12):C.UVGC_409_864,(0,3,13):C.UVGC_409_865,(0,3,14):C.UVGC_409_866,(0,3,15):C.UVGC_409_867,(0,2,0):C.UVGC_390_593,(0,2,1):C.UVGC_390_594,(0,2,2):C.UVGC_390_595,(0,2,3):C.UVGC_390_596,(0,2,4):C.UVGC_390_597,(0,2,5):C.UVGC_390_598,(0,2,6):C.UVGC_390_599,(0,2,10):C.UVGC_390_600,(0,2,11):C.UVGC_390_601,(0,2,7):C.UVGC_390_602,(0,2,9):C.UVGC_390_603,(0,2,12):C.UVGC_390_604,(0,2,13):C.UVGC_390_605,(0,2,14):C.UVGC_390_606,(0,2,15):C.UVGC_390_607,(0,4,0):C.UVGC_404_735,(0,4,1):C.UVGC_404_736,(0,4,2):C.UVGC_404_737,(0,4,3):C.UVGC_404_738,(0,4,4):C.UVGC_404_739,(0,4,5):C.UVGC_404_740,(0,4,6):C.UVGC_390_599,(0,4,10):C.UVGC_404_741,(0,4,11):C.UVGC_404_742,(0,4,7):C.UVGC_390_602,(0,4,9):C.UVGC_390_603,(0,4,12):C.UVGC_404_743,(0,4,13):C.UVGC_404_744,(0,4,14):C.UVGC_404_745,(0,4,15):C.UVGC_404_746,(0,0,8):C.UVGC_228_66})

V_348 = CTVertex(name = 'V_348',
                 type = 'UV',
                 particles = [ P.u__tilde__, P.u ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF5 ],
                 loop_particles = [ [ [P.g, P.u] ], [ [P.sul, P.xglu] ], [ [P.sur, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_104_16,(0,1,0):C.UVGC_267_107,(0,1,1):C.UVGC_332_234,(0,2,0):C.UVGC_267_107,(0,2,2):C.UVGC_341_250})

V_349 = CTVertex(name = 'V_349',
                 type = 'UV',
                 particles = [ P.c__tilde__, P.c ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF5 ],
                 loop_particles = [ [ [P.c, P.g] ], [ [P.scl, P.xglu] ], [ [P.scr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_104_16,(0,1,0):C.UVGC_267_107,(0,1,1):C.UVGC_283_146,(0,2,0):C.UVGC_267_107,(0,2,2):C.UVGC_291_160})

V_350 = CTVertex(name = 'V_350',
                 type = 'UV',
                 particles = [ P.t__tilde__, P.t ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF2, L.FF3, L.FF4, L.FF5 ],
                 loop_particles = [ [ [P.g, P.t] ], [ [P.stl, P.xglu] ], [ [P.str, P.xglu] ] ],
                 couplings = {(0,1,0):C.UVGC_371_536,(0,1,1):C.UVGC_371_537,(0,1,2):C.UVGC_371_538,(0,3,0):C.UVGC_371_536,(0,3,1):C.UVGC_371_537,(0,3,2):C.UVGC_371_538,(0,4,0):C.UVGC_368_527,(0,4,1):C.UVGC_372_539,(0,4,2):C.UVGC_372_540,(0,2,0):C.UVGC_368_527,(0,2,1):C.UVGC_368_528,(0,2,2):C.UVGC_368_529,(0,0,0):C.UVGC_104_16})

V_351 = CTVertex(name = 'V_351',
                 type = 'UV',
                 particles = [ P.d__tilde__, P.d ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF5 ],
                 loop_particles = [ [ [P.d, P.g] ], [ [P.sdl, P.xglu] ], [ [P.sdr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_104_16,(0,1,0):C.UVGC_267_107,(0,1,1):C.UVGC_299_174,(0,2,0):C.UVGC_267_107,(0,2,2):C.UVGC_307_188})

V_352 = CTVertex(name = 'V_352',
                 type = 'UV',
                 particles = [ P.s__tilde__, P.s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF5 ],
                 loop_particles = [ [ [P.g, P.s] ], [ [P.ssl, P.xglu] ], [ [P.ssr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_104_16,(0,1,0):C.UVGC_267_107,(0,1,1):C.UVGC_315_202,(0,2,0):C.UVGC_267_107,(0,2,2):C.UVGC_324_220})

V_353 = CTVertex(name = 'V_353',
                 type = 'UV',
                 particles = [ P.b__tilde__, P.b ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FF1, L.FF3, L.FF5 ],
                 loop_particles = [ [ [P.b, P.g] ], [ [P.sbl, P.xglu] ], [ [P.sbr, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_104_16,(0,1,0):C.UVGC_267_107,(0,1,1):C.UVGC_267_108,(0,2,0):C.UVGC_267_107,(0,2,2):C.UVGC_275_132})

V_354 = CTVertex(name = 'V_354',
                 type = 'UV',
                 particles = [ P.sig8s, P.sig8s ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS3 ],
                 loop_particles = [ [ [P.g, P.sig8s] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_349_306,(0,0,2):C.UVGC_349_307,(0,0,3):C.UVGC_349_308,(0,0,4):C.UVGC_349_309,(0,0,5):C.UVGC_349_310,(0,0,6):C.UVGC_349_311,(0,0,7):C.UVGC_349_312,(0,0,8):C.UVGC_349_313,(0,0,9):C.UVGC_349_314,(0,0,10):C.UVGC_349_315,(0,0,11):C.UVGC_349_316,(0,0,12):C.UVGC_349_317,(0,0,13):C.UVGC_349_318,(0,0,14):C.UVGC_349_319,(0,0,0):C.UVGC_349_320,(0,1,1):C.UVGC_345_254,(0,1,2):C.UVGC_345_255,(0,1,3):C.UVGC_345_256,(0,1,4):C.UVGC_345_257,(0,1,5):C.UVGC_345_258,(0,1,6):C.UVGC_345_259,(0,1,8):C.UVGC_345_260,(0,1,9):C.UVGC_345_261,(0,1,10):C.UVGC_345_262,(0,1,11):C.UVGC_345_263,(0,1,12):C.UVGC_345_264,(0,1,13):C.UVGC_345_265,(0,1,14):C.UVGC_345_266})

V_355 = CTVertex(name = 'V_355',
                 type = 'UV',
                 particles = [ P.sig8p, P.sig8p ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS3 ],
                 loop_particles = [ [ [P.g, P.sig8p] ], [ [P.sig8s] ], [ [P.xglu] ] ],
                 couplings = {(0,0,1):C.UVGC_266_104,(0,0,2):C.UVGC_266_105,(0,0,0):C.UVGC_266_106,(0,1,2):C.UVGC_262_89})

V_356 = CTVertex(name = 'V_356',
                 type = 'UV',
                 particles = [ P.sul__tilde__, P.sul ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.sul] ], [ [P.sig8s, P.sul] ], [ [P.sul] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_340_246,(0,0,0):C.UVGC_340_247,(0,0,1):C.UVGC_340_248,(0,0,3):C.UVGC_340_249,(0,1,1):C.UVGC_337_240,(0,1,3):C.UVGC_337_241})

V_357 = CTVertex(name = 'V_357',
                 type = 'UV',
                 particles = [ P.scl__tilde__, P.scl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scl] ], [ [P.scl] ], [ [P.scl, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_290_156,(0,0,0):C.UVGC_290_157,(0,0,1):C.UVGC_290_158,(0,0,3):C.UVGC_290_159,(0,1,0):C.UVGC_287_150,(0,1,3):C.UVGC_287_151})

V_358 = CTVertex(name = 'V_358',
                 type = 'UV',
                 particles = [ P.stl__tilde__, P.stl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.stl] ], [ [P.sig8s, P.stl] ], [ [P.stl] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_385_579,(0,0,0):C.UVGC_385_580,(0,0,1):C.UVGC_385_581,(0,0,3):C.UVGC_385_582,(0,1,1):C.UVGC_382_573,(0,1,3):C.UVGC_382_574})

V_359 = CTVertex(name = 'V_359',
                 type = 'UV',
                 particles = [ P.sur__tilde__, P.sur ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.sur] ], [ [P.sig8s, P.sur] ], [ [P.sur] ], [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_353_327,(0,0,0):C.UVGC_353_328,(0,0,1):C.UVGC_353_329,(0,0,3):C.UVGC_353_330,(0,1,1):C.UVGC_350_321,(0,1,3):C.UVGC_350_322})

V_360 = CTVertex(name = 'V_360',
                 type = 'UV',
                 particles = [ P.scr__tilde__, P.scr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.c, P.xglu] ], [ [P.g, P.scr] ], [ [P.scr] ], [ [P.scr, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_298_170,(0,0,0):C.UVGC_298_171,(0,0,1):C.UVGC_298_172,(0,0,3):C.UVGC_298_173,(0,1,0):C.UVGC_295_164,(0,1,3):C.UVGC_295_165})

V_361 = CTVertex(name = 'V_361',
                 type = 'UV',
                 particles = [ P.str__tilde__, P.str ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.str] ], [ [P.sig8s, P.str] ], [ [P.str] ], [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,2):C.UVGC_389_589,(0,0,0):C.UVGC_389_590,(0,0,1):C.UVGC_389_591,(0,0,3):C.UVGC_389_592,(0,1,1):C.UVGC_386_583,(0,1,3):C.UVGC_386_584})

V_362 = CTVertex(name = 'V_362',
                 type = 'UV',
                 particles = [ P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdl] ], [ [P.sdl] ], [ [P.sdl, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_306_184,(0,0,0):C.UVGC_306_185,(0,0,1):C.UVGC_306_186,(0,0,3):C.UVGC_306_187,(0,1,0):C.UVGC_303_178,(0,1,3):C.UVGC_303_179})

V_363 = CTVertex(name = 'V_363',
                 type = 'UV',
                 particles = [ P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.ssl] ], [ [P.sig8s, P.ssl] ], [ [P.s, P.xglu] ], [ [P.ssl] ] ],
                 couplings = {(0,0,3):C.UVGC_323_216,(0,0,0):C.UVGC_323_217,(0,0,2):C.UVGC_323_218,(0,0,1):C.UVGC_323_219,(0,1,2):C.UVGC_320_210,(0,1,1):C.UVGC_320_211})

V_364 = CTVertex(name = 'V_364',
                 type = 'UV',
                 particles = [ P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbl] ], [ [P.sbl] ], [ [P.sbl, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_274_128,(0,0,0):C.UVGC_274_129,(0,0,1):C.UVGC_274_130,(0,0,3):C.UVGC_274_131,(0,1,0):C.UVGC_271_117,(0,1,3):C.UVGC_271_118})

V_365 = CTVertex(name = 'V_365',
                 type = 'UV',
                 particles = [ P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.d, P.xglu] ], [ [P.g, P.sdr] ], [ [P.sdr] ], [ [P.sdr, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_314_198,(0,0,0):C.UVGC_314_199,(0,0,1):C.UVGC_314_200,(0,0,3):C.UVGC_314_201,(0,1,0):C.UVGC_311_192,(0,1,3):C.UVGC_311_193})

V_366 = CTVertex(name = 'V_366',
                 type = 'UV',
                 particles = [ P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.g, P.ssr] ], [ [P.sig8s, P.ssr] ], [ [P.s, P.xglu] ], [ [P.ssr] ] ],
                 couplings = {(0,0,3):C.UVGC_331_230,(0,0,0):C.UVGC_331_231,(0,0,2):C.UVGC_331_232,(0,0,1):C.UVGC_331_233,(0,1,2):C.UVGC_328_224,(0,1,1):C.UVGC_328_225})

V_367 = CTVertex(name = 'V_367',
                 type = 'UV',
                 particles = [ P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.SS1, L.SS2 ],
                 loop_particles = [ [ [P.b, P.xglu] ], [ [P.g, P.sbr] ], [ [P.sbr] ], [ [P.sbr, P.sig8s] ] ],
                 couplings = {(0,0,2):C.UVGC_282_142,(0,0,0):C.UVGC_282_143,(0,0,1):C.UVGC_282_144,(0,0,3):C.UVGC_282_145,(0,1,0):C.UVGC_279_136,(0,1,3):C.UVGC_279_137})

V_368 = CTVertex(name = 'V_368',
                 type = 'UV',
                 particles = [ P.g, P.g ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.VV1, L.VV3 ],
                 loop_particles = [ [ [P.g] ], [ [P.ghG] ], [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.sig8p] ], [ [P.sig8s] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ], [ [P.t] ], [ [P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_355_347,(0,0,1):C.UVGC_355_348,(0,0,2):C.UVGC_355_349,(0,0,3):C.UVGC_355_350,(0,0,4):C.UVGC_355_351,(0,0,5):C.UVGC_355_352,(0,0,6):C.UVGC_355_353,(0,0,7):C.UVGC_355_354,(0,0,8):C.UVGC_355_355,(0,0,9):C.UVGC_355_356,(0,0,10):C.UVGC_355_357,(0,0,11):C.UVGC_355_358,(0,0,12):C.UVGC_355_359,(0,0,13):C.UVGC_355_360,(0,0,14):C.UVGC_355_361,(0,0,15):C.UVGC_355_362,(0,0,16):C.UVGC_355_363,(0,0,17):C.UVGC_355_364,(0,1,2):C.UVGC_354_331,(0,1,3):C.UVGC_354_332,(0,1,4):C.UVGC_354_333,(0,1,5):C.UVGC_354_334,(0,1,6):C.UVGC_354_335,(0,1,7):C.UVGC_354_336,(0,1,8):C.UVGC_354_337,(0,1,9):C.UVGC_354_338,(0,1,10):C.UVGC_354_339,(0,1,11):C.UVGC_354_340,(0,1,12):C.UVGC_354_341,(0,1,13):C.UVGC_354_342,(0,1,14):C.UVGC_354_343,(0,1,15):C.UVGC_354_344,(0,1,16):C.UVGC_354_345,(0,1,17):C.UVGC_354_346})

V_369 = CTVertex(name = 'V_369',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.xglu, P.a ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.sbl], [P.d, P.sdl], [P.s, P.ssl] ], [ [P.b, P.sbr], [P.d, P.sdr], [P.s, P.ssr] ], [ [P.c, P.scl], [P.stl, P.t], [P.sul, P.u] ], [ [P.c, P.scr], [P.str, P.t], [P.sur, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_212_58,(0,0,1):C.UVGC_212_59,(0,0,2):C.UVGC_212_60,(0,0,3):C.UVGC_212_61})

V_370 = CTVertex(name = 'V_370',
                 type = 'UV',
                 particles = [ P.xglu__tilde__, P.xglu, P.Z ],
                 color = [ 'Identity(1,2)' ],
                 lorentz = [ L.FFV3 ],
                 loop_particles = [ [ [P.b, P.sbl], [P.d, P.sdl], [P.s, P.ssl] ], [ [P.b, P.sbr], [P.d, P.sdr], [P.s, P.ssr] ], [ [P.c, P.scl], [P.stl, P.t], [P.sul, P.u] ], [ [P.c, P.scr], [P.str, P.t], [P.sur, P.u] ] ],
                 couplings = {(0,0,0):C.UVGC_213_62,(0,0,1):C.UVGC_213_63,(0,0,2):C.UVGC_213_64,(0,0,3):C.UVGC_213_65})

V_371 = CTVertex(name = 'V_371',
                 type = 'UV',
                 particles = [ P.a, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_372 = CTVertex(name = 'V_372',
                 type = 'UV',
                 particles = [ P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_128_37,(0,1,0):C.UVGC_129_38})

V_373 = CTVertex(name = 'V_373',
                 type = 'UV',
                 particles = [ P.a, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_374 = CTVertex(name = 'V_374',
                 type = 'UV',
                 particles = [ P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_128_37,(0,1,0):C.UVGC_129_38})

V_375 = CTVertex(name = 'V_375',
                 type = 'UV',
                 particles = [ P.a, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_376 = CTVertex(name = 'V_376',
                 type = 'UV',
                 particles = [ P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_128_37,(0,1,0):C.UVGC_129_38})

V_377 = CTVertex(name = 'V_377',
                 type = 'UV',
                 particles = [ P.a, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_378 = CTVertex(name = 'V_378',
                 type = 'UV',
                 particles = [ P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_130_39,(0,1,0):C.UVGC_131_40})

V_379 = CTVertex(name = 'V_379',
                 type = 'UV',
                 particles = [ P.a, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_380 = CTVertex(name = 'V_380',
                 type = 'UV',
                 particles = [ P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_130_39,(0,1,0):C.UVGC_131_40})

V_381 = CTVertex(name = 'V_381',
                 type = 'UV',
                 particles = [ P.a, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_125_34,(0,1,0):C.UVGC_124_33})

V_382 = CTVertex(name = 'V_382',
                 type = 'UV',
                 particles = [ P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_130_39,(0,1,0):C.UVGC_131_40})

V_383 = CTVertex(name = 'V_383',
                 type = 'UV',
                 particles = [ P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_231_69,(0,1,0):C.UVGC_232_70})

V_384 = CTVertex(name = 'V_384',
                 type = 'UV',
                 particles = [ P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_232_70,(0,1,0):C.UVGC_231_69})

V_385 = CTVertex(name = 'V_385',
                 type = 'UV',
                 particles = [ P.a, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_386 = CTVertex(name = 'V_386',
                 type = 'UV',
                 particles = [ P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_111_23,(0,1,0):C.UVGC_112_24})

V_387 = CTVertex(name = 'V_387',
                 type = 'UV',
                 particles = [ P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_232_70,(0,1,0):C.UVGC_231_69})

V_388 = CTVertex(name = 'V_388',
                 type = 'UV',
                 particles = [ P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_231_69,(0,1,0):C.UVGC_232_70})

V_389 = CTVertex(name = 'V_389',
                 type = 'UV',
                 particles = [ P.a, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_390 = CTVertex(name = 'V_390',
                 type = 'UV',
                 particles = [ P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_111_23,(0,1,0):C.UVGC_112_24})

V_391 = CTVertex(name = 'V_391',
                 type = 'UV',
                 particles = [ P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_231_69,(0,1,0):C.UVGC_232_70})

V_392 = CTVertex(name = 'V_392',
                 type = 'UV',
                 particles = [ P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_232_70,(0,1,0):C.UVGC_231_69})

V_393 = CTVertex(name = 'V_393',
                 type = 'UV',
                 particles = [ P.a, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_394 = CTVertex(name = 'V_394',
                 type = 'UV',
                 particles = [ P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_111_23,(0,1,0):C.UVGC_112_24})

V_395 = CTVertex(name = 'V_395',
                 type = 'UV',
                 particles = [ P.a, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_396 = CTVertex(name = 'V_396',
                 type = 'UV',
                 particles = [ P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_114_26,(0,1,0):C.UVGC_113_25})

V_397 = CTVertex(name = 'V_397',
                 type = 'UV',
                 particles = [ P.a, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_398 = CTVertex(name = 'V_398',
                 type = 'UV',
                 particles = [ P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_114_26,(0,1,0):C.UVGC_113_25})

V_399 = CTVertex(name = 'V_399',
                 type = 'UV',
                 particles = [ P.a, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_107_19,(0,1,0):C.UVGC_108_20})

V_400 = CTVertex(name = 'V_400',
                 type = 'UV',
                 particles = [ P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.VSS1, L.VSS3 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_114_26,(0,1,0):C.UVGC_113_25})

V_401 = CTVertex(name = 'V_401',
                 type = 'UV',
                 particles = [ P.H, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_208_57})

V_402 = CTVertex(name = 'V_402',
                 type = 'UV',
                 particles = [ P.H, P.str__tilde__, P.str ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_208_57})

V_403 = CTVertex(name = 'V_403',
                 type = 'UV',
                 particles = [ P.G__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_254_84})

V_404 = CTVertex(name = 'V_404',
                 type = 'UV',
                 particles = [ P.G__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(2,3)' ],
                 lorentz = [ L.SSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_253_83})

V_405 = CTVertex(name = 'V_405',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_406 = CTVertex(name = 'V_406',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_407 = CTVertex(name = 'V_407',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_132_41})

V_408 = CTVertex(name = 'V_408',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_136_45})

V_409 = CTVertex(name = 'V_409',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sul__tilde__, P.sul ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_410 = CTVertex(name = 'V_410',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sul__tilde__, P.sul ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_134_43})

V_411 = CTVertex(name = 'V_411',
                 type = 'UV',
                 particles = [ P.a, P.a, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_412 = CTVertex(name = 'V_412',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_413 = CTVertex(name = 'V_413',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_132_41})

V_414 = CTVertex(name = 'V_414',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_136_45})

V_415 = CTVertex(name = 'V_415',
                 type = 'UV',
                 particles = [ P.a, P.g, P.scl__tilde__, P.scl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_416 = CTVertex(name = 'V_416',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.scl__tilde__, P.scl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_134_43})

V_417 = CTVertex(name = 'V_417',
                 type = 'UV',
                 particles = [ P.a, P.a, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_418 = CTVertex(name = 'V_418',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_419 = CTVertex(name = 'V_419',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_132_41})

V_420 = CTVertex(name = 'V_420',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_136_45})

V_421 = CTVertex(name = 'V_421',
                 type = 'UV',
                 particles = [ P.a, P.g, P.stl__tilde__, P.stl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_422 = CTVertex(name = 'V_422',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.stl__tilde__, P.stl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_134_43})

V_423 = CTVertex(name = 'V_423',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_424 = CTVertex(name = 'V_424',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_133_42})

V_425 = CTVertex(name = 'V_425',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_137_46})

V_426 = CTVertex(name = 'V_426',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sur__tilde__, P.sur ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_427 = CTVertex(name = 'V_427',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sur__tilde__, P.sur ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_135_44})

V_428 = CTVertex(name = 'V_428',
                 type = 'UV',
                 particles = [ P.a, P.a, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_429 = CTVertex(name = 'V_429',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_133_42})

V_430 = CTVertex(name = 'V_430',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_137_46})

V_431 = CTVertex(name = 'V_431',
                 type = 'UV',
                 particles = [ P.a, P.g, P.scr__tilde__, P.scr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_432 = CTVertex(name = 'V_432',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.scr__tilde__, P.scr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_135_44})

V_433 = CTVertex(name = 'V_433',
                 type = 'UV',
                 particles = [ P.a, P.a, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_126_35})

V_434 = CTVertex(name = 'V_434',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_133_42})

V_435 = CTVertex(name = 'V_435',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.str__tilde__, P.str ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_137_46})

V_436 = CTVertex(name = 'V_436',
                 type = 'UV',
                 particles = [ P.a, P.g, P.str__tilde__, P.str ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_127_36})

V_437 = CTVertex(name = 'V_437',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.str__tilde__, P.str ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_135_44})

V_438 = CTVertex(name = 'V_438',
                 type = 'UV',
                 particles = [ P.a, P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_439 = CTVertex(name = 'V_439',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Z, P.sdl, P.sul__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_440 = CTVertex(name = 'V_440',
                 type = 'UV',
                 particles = [ P.g, P.W__plus__, P.sdl, P.sul__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_441 = CTVertex(name = 'V_441',
                 type = 'UV',
                 particles = [ P.a, P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_442 = CTVertex(name = 'V_442',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Z, P.sdl__tilde__, P.sul ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_443 = CTVertex(name = 'V_443',
                 type = 'UV',
                 particles = [ P.g, P.W__minus__, P.sdl__tilde__, P.sul ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_444 = CTVertex(name = 'V_444',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_445 = CTVertex(name = 'V_445',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.u, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_446 = CTVertex(name = 'V_446',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_115_27})

V_447 = CTVertex(name = 'V_447',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_119_31})

V_448 = CTVertex(name = 'V_448',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sdl__tilde__, P.sdl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_449 = CTVertex(name = 'V_449',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sdl__tilde__, P.sdl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_117_29})

V_450 = CTVertex(name = 'V_450',
                 type = 'UV',
                 particles = [ P.a, P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_451 = CTVertex(name = 'V_451',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Z, P.scl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_452 = CTVertex(name = 'V_452',
                 type = 'UV',
                 particles = [ P.g, P.W__plus__, P.scl__tilde__, P.ssl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_453 = CTVertex(name = 'V_453',
                 type = 'UV',
                 particles = [ P.a, P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_454 = CTVertex(name = 'V_454',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Z, P.scl, P.ssl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_455 = CTVertex(name = 'V_455',
                 type = 'UV',
                 particles = [ P.g, P.W__minus__, P.scl, P.ssl__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_456 = CTVertex(name = 'V_456',
                 type = 'UV',
                 particles = [ P.a, P.a, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_457 = CTVertex(name = 'V_457',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.c, P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_458 = CTVertex(name = 'V_458',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_115_27})

V_459 = CTVertex(name = 'V_459',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_119_31})

V_460 = CTVertex(name = 'V_460',
                 type = 'UV',
                 particles = [ P.a, P.g, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_461 = CTVertex(name = 'V_461',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.ssl__tilde__, P.ssl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_117_29})

V_462 = CTVertex(name = 'V_462',
                 type = 'UV',
                 particles = [ P.a, P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_463 = CTVertex(name = 'V_463',
                 type = 'UV',
                 particles = [ P.W__plus__, P.Z, P.sbl, P.stl__tilde__ ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_464 = CTVertex(name = 'V_464',
                 type = 'UV',
                 particles = [ P.g, P.W__plus__, P.sbl, P.stl__tilde__ ],
                 color = [ 'T(1,3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_465 = CTVertex(name = 'V_465',
                 type = 'UV',
                 particles = [ P.a, P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_233_71})

V_466 = CTVertex(name = 'V_466',
                 type = 'UV',
                 particles = [ P.W__minus__, P.Z, P.sbl__tilde__, P.stl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_229_67})

V_467 = CTVertex(name = 'V_467',
                 type = 'UV',
                 particles = [ P.g, P.W__minus__, P.sbl__tilde__, P.stl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_234_72})

V_468 = CTVertex(name = 'V_468',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_469 = CTVertex(name = 'V_469',
                 type = 'UV',
                 particles = [ P.W__minus__, P.W__plus__, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.t, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_230_68})

V_470 = CTVertex(name = 'V_470',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_115_27})

V_471 = CTVertex(name = 'V_471',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_119_31})

V_472 = CTVertex(name = 'V_472',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sbl__tilde__, P.sbl ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_473 = CTVertex(name = 'V_473',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sbl__tilde__, P.sbl ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_117_29})

V_474 = CTVertex(name = 'V_474',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_475 = CTVertex(name = 'V_475',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_116_28})

V_476 = CTVertex(name = 'V_476',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_120_32})

V_477 = CTVertex(name = 'V_477',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sdr__tilde__, P.sdr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_478 = CTVertex(name = 'V_478',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sdr__tilde__, P.sdr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.d, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_118_30})

V_479 = CTVertex(name = 'V_479',
                 type = 'UV',
                 particles = [ P.a, P.a, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_480 = CTVertex(name = 'V_480',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_116_28})

V_481 = CTVertex(name = 'V_481',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_120_32})

V_482 = CTVertex(name = 'V_482',
                 type = 'UV',
                 particles = [ P.a, P.g, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_483 = CTVertex(name = 'V_483',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.ssr__tilde__, P.ssr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.s, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_118_30})

V_484 = CTVertex(name = 'V_484',
                 type = 'UV',
                 particles = [ P.a, P.a, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_109_21})

V_485 = CTVertex(name = 'V_485',
                 type = 'UV',
                 particles = [ P.a, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_116_28})

V_486 = CTVertex(name = 'V_486',
                 type = 'UV',
                 particles = [ P.Z, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'Identity(3,4)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_120_32})

V_487 = CTVertex(name = 'V_487',
                 type = 'UV',
                 particles = [ P.a, P.g, P.sbr__tilde__, P.sbr ],
                 color = [ 'T(2,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_110_22})

V_488 = CTVertex(name = 'V_488',
                 type = 'UV',
                 particles = [ P.g, P.Z, P.sbr__tilde__, P.sbr ],
                 color = [ 'T(1,4,3)' ],
                 lorentz = [ L.VVSS1 ],
                 loop_particles = [ [ [P.b, P.xglu] ] ],
                 couplings = {(0,0,0):C.UVGC_118_30})

# V_489 = CTVertex(name = 'V_489',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.sig8s ],
#                  color = [ '1' ],
#                  lorentz = [ L.SS1, L.SS2 ],
#                  loop_particles = [ [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ] ],
#                  couplings = {(0,0,0):C.UVGC_507_896,(0,0,1):C.UVGC_507_897,(0,0,2):C.UVGC_507_898,(0,0,3):C.UVGC_507_899,(0,0,4):C.UVGC_507_900,(0,0,5):C.UVGC_507_901,(0,0,6):C.UVGC_507_902,(0,0,7):C.UVGC_507_903,(0,0,8):C.UVGC_507_904,(0,0,9):C.UVGC_507_905,(0,0,10):C.UVGC_507_906,(0,0,11):C.UVGC_507_907,(0,1,0):C.UVGC_506_884,(0,1,1):C.UVGC_506_885,(0,1,2):C.UVGC_506_886,(0,1,3):C.UVGC_506_887,(0,1,4):C.UVGC_506_888,(0,1,5):C.UVGC_506_889,(0,1,6):C.UVGC_506_890,(0,1,7):C.UVGC_506_891,(0,1,8):C.UVGC_506_892,(0,1,9):C.UVGC_506_893,(0,1,10):C.UVGC_506_894,(0,1,11):C.UVGC_506_895})

# V_490 = CTVertex(name = 'V_490',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.sig8s, P.sig8s ],
#                  color = [ '1' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sbl], [P.sbr], [P.scl], [P.scr], [P.sdl], [P.sdr], [P.ssl], [P.ssr], [P.stl], [P.str], [P.sul], [P.sur] ] ],
#                  couplings = {(0,0,0):C.UVGC_511_944})

# V_491 = CTVertex(name = 'V_491',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.sul__tilde__, P.sul ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.sul] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_492 = CTVertex(name = 'V_492',
#                  type = 'UV',
#                  particles = [ P.scl__tilde__, P.scl, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.scl, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_493 = CTVertex(name = 'V_493',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.stl__tilde__, P.stl ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.stl] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_494 = CTVertex(name = 'V_494',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.sur__tilde__, P.sur ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.sur] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_495 = CTVertex(name = 'V_495',
#                  type = 'UV',
#                  particles = [ P.scr__tilde__, P.scr, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.scr, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_496 = CTVertex(name = 'V_496',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.str__tilde__, P.str ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.str] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_497 = CTVertex(name = 'V_497',
#                  type = 'UV',
#                  particles = [ P.sdl__tilde__, P.sdl, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sdl, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_498 = CTVertex(name = 'V_498',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.ssl__tilde__, P.ssl ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.ssl] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_499 = CTVertex(name = 'V_499',
#                  type = 'UV',
#                  particles = [ P.sbl__tilde__, P.sbl, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sbl, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_500 = CTVertex(name = 'V_500',
#                  type = 'UV',
#                  particles = [ P.sdr__tilde__, P.sdr, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sdr, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_501 = CTVertex(name = 'V_501',
#                  type = 'UV',
#                  particles = [ P.sig8p, P.ssr__tilde__, P.ssr ],
#                  color = [ '1', 'T(1,3,-1)*T(4,-1,2)', 'T(2,3,-1)*T(4,-1,2)', 'T(3,3,-1)*T(4,-1,2)', 'T(4,-1,2)*T(4,3,-1)', 'T(4,-1,2)*T(5,3,-1)', 'T(4,-1,2)*T(6,3,-1)', 'T(4,-1,2)*T(7,3,-1)', 'T(4,-1,2)*T(8,3,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sig8s, P.ssr] ] ],
#                  couplings = {(1,0,0):C.UVGC_410_868,(2,0,0):C.UVGC_416_869,(3,0,0):C.UVGC_422_870,(4,0,0):C.UVGC_428_871,(5,0,0):C.UVGC_434_872,(6,0,0):C.UVGC_440_873,(7,0,0):C.UVGC_446_874,(8,0,0):C.UVGC_452_875,(0,0,0):C.UVGC_519_958})

# V_502 = CTVertex(name = 'V_502',
#                  type = 'UV',
#                  particles = [ P.sbr__tilde__, P.sbr, P.sig8p ],
#                  color = [ '1', 'T(1,2,-1)*T(4,-1,1)', 'T(2,2,-1)*T(4,-1,1)', 'T(3,2,-1)*T(4,-1,1)', 'T(4,-1,1)*T(4,2,-1)', 'T(4,-1,1)*T(5,2,-1)', 'T(4,-1,1)*T(6,2,-1)', 'T(4,-1,1)*T(7,2,-1)', 'T(4,-1,1)*T(8,2,-1)' ],
#                  lorentz = [ L.SSS1 ],
#                  loop_particles = [ [ [P.sbr, P.sig8s] ] ],
#                  couplings = {(1,0,0):C.UVGC_458_876,(2,0,0):C.UVGC_464_877,(3,0,0):C.UVGC_470_878,(4,0,0):C.UVGC_476_879,(5,0,0):C.UVGC_482_880,(6,0,0):C.UVGC_488_881,(7,0,0):C.UVGC_494_882,(8,0,0):C.UVGC_500_883,(0,0,0):C.UVGC_513_957})

# V_503 = CTVertex(name = 'V_503',
#                  type = 'UV',
#                  particles = [ P.g, P.g, P.sig8p, P.sig8s ],
#                  color = [ '1' ],
#                  lorentz = [ L.VVSS1 ],
#                  loop_particles = [ [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ] ],
#                  couplings = {(0,0,0):C.UVGC_512_945,(0,0,1):C.UVGC_512_946,(0,0,2):C.UVGC_512_947,(0,0,3):C.UVGC_512_948,(0,0,4):C.UVGC_512_949,(0,0,5):C.UVGC_512_950,(0,0,6):C.UVGC_512_951,(0,0,7):C.UVGC_512_952,(0,0,8):C.UVGC_512_953,(0,0,9):C.UVGC_512_954,(0,0,10):C.UVGC_512_955,(0,0,11):C.UVGC_512_956})

# V_504 = CTVertex(name = 'V_504',
#                  type = 'UV',
#                  particles = [ P.g, P.sig8p, P.sig8s ],
#                  color = [ '1' ],
#                  lorentz = [ L.VSS2 ],
#                  loop_particles = [ [ [P.sbl] ], [ [P.sbr] ], [ [P.scl] ], [ [P.scr] ], [ [P.sdl] ], [ [P.sdr] ], [ [P.ssl] ], [ [P.ssr] ], [ [P.stl] ], [ [P.str] ], [ [P.sul] ], [ [P.sur] ] ],
#                  couplings = {(0,0,0):C.UVGC_510_932,(0,0,1):C.UVGC_510_933,(0,0,2):C.UVGC_510_934,(0,0,3):C.UVGC_510_935,(0,0,4):C.UVGC_510_936,(0,0,5):C.UVGC_510_937,(0,0,6):C.UVGC_510_938,(0,0,7):C.UVGC_510_939,(0,0,8):C.UVGC_510_940,(0,0,9):C.UVGC_510_941,(0,0,10):C.UVGC_510_942,(0,0,11):C.UVGC_510_943})

