# This file was automatically created by FeynRules 2.3.15
# Mathematica version: 9.0 for Linux x86 (64-bit) (February 7, 2013)
# Date: Sat 5 Mar 2016 02:29:50


from object_library import all_decays, Decay
import particles as P


Decay_H = Decay(name = 'Decay_H',
                particle = P.H,
                partial_widths = {(P.b,P.b__tilde__):'(3*MH**4*yb**2)/(16.*cmath.pi*abs(MH)**3)',
                                  (P.t,P.t__tilde__):'((3*MH**2*yt**2 - 12*MT**2*yt**2)*cmath.sqrt(MH**4 - 4*MH**2*MT**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((MH**2*ytau**2 - 4*MTA**2*ytau**2)*cmath.sqrt(MH**4 - 4*MH**2*MTA**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.W__minus__,P.W__plus__):'(((3*ee**4*vev**2)/(4.*sw**4) + (ee**4*MH**4*vev**2)/(16.*MW**4*sw**4) - (ee**4*MH**2*vev**2)/(4.*MW**2*sw**4))*cmath.sqrt(MH**4 - 4*MH**2*MW**2))/(16.*cmath.pi*abs(MH)**3)',
                                  (P.Z,P.Z):'(((9*ee**4*vev**2)/2. + (3*ee**4*MH**4*vev**2)/(8.*MZ**4) - (3*ee**4*MH**2*vev**2)/(2.*MZ**2) + (3*cw**4*ee**4*vev**2)/(4.*sw**4) + (cw**4*ee**4*MH**4*vev**2)/(16.*MZ**4*sw**4) - (cw**4*ee**4*MH**2*vev**2)/(4.*MZ**2*sw**4) + (3*cw**2*ee**4*vev**2)/sw**2 + (cw**2*ee**4*MH**4*vev**2)/(4.*MZ**4*sw**2) - (cw**2*ee**4*MH**2*vev**2)/(MZ**2*sw**2) + (3*ee**4*sw**2*vev**2)/cw**2 + (ee**4*MH**4*sw**2*vev**2)/(4.*cw**2*MZ**4) - (ee**4*MH**2*sw**2*vev**2)/(cw**2*MZ**2) + (3*ee**4*sw**4*vev**2)/(4.*cw**4) + (ee**4*MH**4*sw**4*vev**2)/(16.*cw**4*MZ**4) - (ee**4*MH**2*sw**4*vev**2)/(4.*cw**4*MZ**2))*cmath.sqrt(MH**4 - 4*MH**2*MZ**2))/(32.*cmath.pi*abs(MH)**3)'})

Decay_sbl = Decay(name = 'Decay_sbl',
                  particle = P.sbl,
                  partial_widths = {(P.b,P.xglu):'((-MD3**2 + msbl**2)*(-8*G**2*MD3**2 + 8*G**2*msbl**2))/(48.*cmath.pi*abs(msbl)**3)'})

Decay_sbr = Decay(name = 'Decay_sbr',
                  particle = P.sbr,
                  partial_widths = {(P.b,P.xglu__tilde__):'((-MD3**2 + msbr**2)*(-8*G**2*MD3**2 + 8*G**2*msbr**2))/(48.*cmath.pi*abs(msbr)**3)'})

Decay_scl = Decay(name = 'Decay_scl',
                  particle = P.scl,
                  partial_widths = {(P.c,P.xglu):'((-MD3**2 + mscl**2)*(-8*G**2*MD3**2 + 8*G**2*mscl**2))/(48.*cmath.pi*abs(mscl)**3)'})

Decay_scr = Decay(name = 'Decay_scr',
                  particle = P.scr,
                  partial_widths = {(P.c,P.xglu__tilde__):'((-MD3**2 + mscr**2)*(-8*G**2*MD3**2 + 8*G**2*mscr**2))/(48.*cmath.pi*abs(mscr)**3)'})

Decay_sdl = Decay(name = 'Decay_sdl',
                  particle = P.sdl,
                  partial_widths = {(P.d,P.xglu):'((-MD3**2 + msdl**2)*(-8*G**2*MD3**2 + 8*G**2*msdl**2))/(48.*cmath.pi*abs(msdl)**3)'})

Decay_sdr = Decay(name = 'Decay_sdr',
                  particle = P.sdr,
                  partial_widths = {(P.d,P.xglu__tilde__):'((-MD3**2 + msdr**2)*(-8*G**2*MD3**2 + 8*G**2*msdr**2))/(48.*cmath.pi*abs(msdr)**3)'})

Decay_sig8p = Decay(name = 'Decay_sig8p',
                    particle = P.sig8p,
                    partial_widths = {(P.xglu,P.xglu__tilde__):'(G**2*mOp**2*f(1,2,3)**2*cmath.sqrt(-4*MD3**2*mOp**2 + mOp**4))/(64.*cmath.pi*abs(mOp)**3)'})

Decay_sig8s = Decay(name = 'Decay_sig8s',
                    particle = P.sig8s,
                    partial_widths = {(P.sbl__tilde__,P.sbl):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msbl**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.sbr__tilde__,P.sbr):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msbr**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.scl__tilde__,P.scl):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mscl**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.scr__tilde__,P.scr):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mscr**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.sdl__tilde__,P.sdl):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msdl**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.sdr__tilde__,P.sdr):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msdr**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.ssl__tilde__,P.ssl):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mssl**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.ssr__tilde__,P.ssr):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mssr**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.stl__tilde__,P.stl):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mstl**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.str__tilde__,P.str):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*mstr**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.sul__tilde__,P.sul):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msul**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.sur__tilde__,P.sur):'(G**2*MD3**2*cmath.sqrt(mOs**4 - 4*mOs**2*msur**2))/(8.*cmath.pi*abs(mOs)**3)',
                                      (P.xglu,P.xglu__tilde__):'((-8*G**2*MD3**2*f(1,2,3)**2 + 2*G**2*mOs**2*f(1,2,3)**2)*cmath.sqrt(-4*MD3**2*mOs**2 + mOs**4))/(128.*cmath.pi*abs(mOs)**3)'})

Decay_ssl = Decay(name = 'Decay_ssl',
                  particle = P.ssl,
                  partial_widths = {(P.s,P.xglu):'((-MD3**2 + mssl**2)*(-8*G**2*MD3**2 + 8*G**2*mssl**2))/(48.*cmath.pi*abs(mssl)**3)'})

Decay_ssr = Decay(name = 'Decay_ssr',
                  particle = P.ssr,
                  partial_widths = {(P.s,P.xglu__tilde__):'((-MD3**2 + mssr**2)*(-8*G**2*MD3**2 + 8*G**2*mssr**2))/(48.*cmath.pi*abs(mssr)**3)'})

Decay_stl = Decay(name = 'Decay_stl',
                  particle = P.stl,
                  partial_widths = {(P.t,P.xglu):'((-8*G**2*MD3**2 + 8*G**2*mstl**2 - 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstl**2 + mstl**4 - 2*MD3**2*MT**2 - 2*mstl**2*MT**2 + MT**4))/(48.*cmath.pi*abs(mstl)**3)'})

Decay_str = Decay(name = 'Decay_str',
                  particle = P.str,
                  partial_widths = {(P.t,P.xglu__tilde__):'((-8*G**2*MD3**2 + 8*G**2*mstr**2 - 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstr**2 + mstr**4 - 2*MD3**2*MT**2 - 2*mstr**2*MT**2 + MT**4))/(48.*cmath.pi*abs(mstr)**3)'})

Decay_sul = Decay(name = 'Decay_sul',
                  particle = P.sul,
                  partial_widths = {(P.u,P.xglu):'((-MD3**2 + msul**2)*(-8*G**2*MD3**2 + 8*G**2*msul**2))/(48.*cmath.pi*abs(msul)**3)'})

Decay_sur = Decay(name = 'Decay_sur',
                  particle = P.sur,
                  partial_widths = {(P.u,P.xglu__tilde__):'((-MD3**2 + msur**2)*(-8*G**2*MD3**2 + 8*G**2*msur**2))/(48.*cmath.pi*abs(msur)**3)'})

Decay_t = Decay(name = 'Decay_t',
                particle = P.t,
                partial_widths = {(P.stl,P.xglu__tilde__):'((8*G**2*MD3**2 - 8*G**2*mstl**2 + 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstl**2 + mstl**4 - 2*MD3**2*MT**2 - 2*mstl**2*MT**2 + MT**4))/(96.*cmath.pi*abs(MT)**3)',
                                  (P.str,P.xglu):'((8*G**2*MD3**2 - 8*G**2*mstr**2 + 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstr**2 + mstr**4 - 2*MD3**2*MT**2 - 2*mstr**2*MT**2 + MT**4))/(96.*cmath.pi*abs(MT)**3)',
                                  (P.W__plus__,P.b):'((MT**2 - MW**2)*((3*ee**2*MT**2)/(2.*sw**2) + (3*ee**2*MT**4)/(2.*MW**2*sw**2) - (3*ee**2*MW**2)/sw**2))/(96.*cmath.pi*abs(MT)**3)'})

Decay_ta__minus__ = Decay(name = 'Decay_ta__minus__',
                          particle = P.ta__minus__,
                          partial_widths = {(P.W__minus__,P.vt):'(((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*MTA**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*Mnu**2*MTA**2)/(MW**2*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2)*cmath.sqrt(Mnu**4 - 2*Mnu**2*MTA**2 + MTA**4 - 2*Mnu**2*MW**2 - 2*MTA**2*MW**2 + MW**4))/(32.*cmath.pi*abs(MTA)**3)'})

Decay_ve = Decay(name = 'Decay_ve',
                 particle = P.ve,
                 partial_widths = {(P.W__plus__,P.e__minus__):'((Mnu**2 - MW**2)*((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(Mnu)**3)',
                                   (P.W__minus__,P.e__plus__):'((Mnu**2 - MW**2)*((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(Mnu)**3)'})

Decay_vm = Decay(name = 'Decay_vm',
                 particle = P.vm,
                 partial_widths = {(P.W__plus__,P.mu__minus__):'((Mnu**2 - MW**2)*((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(Mnu)**3)',
                                   (P.W__minus__,P.mu__plus__):'((Mnu**2 - MW**2)*((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2))/(32.*cmath.pi*abs(Mnu)**3)'})

Decay_vt = Decay(name = 'Decay_vt',
                 particle = P.vt,
                 partial_widths = {(P.W__plus__,P.ta__minus__):'(((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*MTA**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*Mnu**2*MTA**2)/(MW**2*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2)*cmath.sqrt(Mnu**4 - 2*Mnu**2*MTA**2 + MTA**4 - 2*Mnu**2*MW**2 - 2*MTA**2*MW**2 + MW**4))/(32.*cmath.pi*abs(Mnu)**3)',
                                   (P.W__minus__,P.ta__plus__):'(((ee**2*Mnu**2)/(2.*sw**2) + (ee**2*MTA**2)/(2.*sw**2) + (ee**2*Mnu**4)/(2.*MW**2*sw**2) - (ee**2*Mnu**2*MTA**2)/(MW**2*sw**2) + (ee**2*MTA**4)/(2.*MW**2*sw**2) - (ee**2*MW**2)/sw**2)*cmath.sqrt(Mnu**4 - 2*Mnu**2*MTA**2 + MTA**4 - 2*Mnu**2*MW**2 - 2*MTA**2*MW**2 + MW**4))/(32.*cmath.pi*abs(Mnu)**3)'})

Decay_W__plus__ = Decay(name = 'Decay_W__plus__',
                        particle = P.W__plus__,
                        partial_widths = {(P.c,P.s__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.t,P.b__tilde__):'((-MT**2 + MW**2)*((-3*ee**2*MT**2)/(2.*sw**2) - (3*ee**2*MT**4)/(2.*MW**2*sw**2) + (3*ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.u,P.d__tilde__):'(ee**2*MW**4)/(16.*cmath.pi*sw**2*abs(MW)**3)',
                                          (P.ve,P.e__plus__):'((-Mnu**2 + MW**2)*(-(ee**2*Mnu**2)/(2.*sw**2) - (ee**2*Mnu**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.vm,P.mu__plus__):'((-Mnu**2 + MW**2)*(-(ee**2*Mnu**2)/(2.*sw**2) - (ee**2*Mnu**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2))/(48.*cmath.pi*abs(MW)**3)',
                                          (P.vt,P.ta__plus__):'((-(ee**2*Mnu**2)/(2.*sw**2) - (ee**2*MTA**2)/(2.*sw**2) - (ee**2*Mnu**4)/(2.*MW**2*sw**2) + (ee**2*Mnu**2*MTA**2)/(MW**2*sw**2) - (ee**2*MTA**4)/(2.*MW**2*sw**2) + (ee**2*MW**2)/sw**2)*cmath.sqrt(Mnu**4 - 2*Mnu**2*MTA**2 + MTA**4 - 2*Mnu**2*MW**2 - 2*MTA**2*MW**2 + MW**4))/(48.*cmath.pi*abs(MW)**3)'})

Decay_xglu = Decay(name = 'Decay_xglu',
                   particle = P.xglu,
                   partial_widths = {(P.sbl,P.b__tilde__):'((MD3**2 - msbl**2)*(8*G**2*MD3**2 - 8*G**2*msbl**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.sbr__tilde__,P.b):'((MD3**2 - msbr**2)*(8*G**2*MD3**2 - 8*G**2*msbr**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.scl,P.c__tilde__):'((MD3**2 - mscl**2)*(8*G**2*MD3**2 - 8*G**2*mscl**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.scr__tilde__,P.c):'((MD3**2 - mscr**2)*(8*G**2*MD3**2 - 8*G**2*mscr**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.sdl,P.d__tilde__):'((MD3**2 - msdl**2)*(8*G**2*MD3**2 - 8*G**2*msdl**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.sdr__tilde__,P.d):'((MD3**2 - msdr**2)*(8*G**2*MD3**2 - 8*G**2*msdr**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.ssl,P.s__tilde__):'((MD3**2 - mssl**2)*(8*G**2*MD3**2 - 8*G**2*mssl**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.ssr__tilde__,P.s):'((MD3**2 - mssr**2)*(8*G**2*MD3**2 - 8*G**2*mssr**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.stl,P.t__tilde__):'((8*G**2*MD3**2 - 8*G**2*mstl**2 + 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstl**2 + mstl**4 - 2*MD3**2*MT**2 - 2*mstl**2*MT**2 + MT**4))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.str__tilde__,P.t):'((8*G**2*MD3**2 - 8*G**2*mstr**2 + 8*G**2*MT**2)*cmath.sqrt(MD3**4 - 2*MD3**2*mstr**2 + mstr**4 - 2*MD3**2*MT**2 - 2*mstr**2*MT**2 + MT**4))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.sul,P.u__tilde__):'((MD3**2 - msul**2)*(8*G**2*MD3**2 - 8*G**2*msul**2))/(256.*cmath.pi*abs(MD3)**3)',
                                     (P.sur__tilde__,P.u):'((MD3**2 - msur**2)*(8*G**2*MD3**2 - 8*G**2*msur**2))/(256.*cmath.pi*abs(MD3)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.b,P.b__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.c,P.c__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.d,P.d__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.e__minus__,P.e__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'(MZ**2*(-(ee**2*MZ**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.s,P.s__tilde__):'(MZ**2*(ee**2*MZ**2 + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (5*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.t,P.t__tilde__):'((-11*ee**2*MT**2 - ee**2*MZ**2 - (3*cw**2*ee**2*MT**2)/(2.*sw**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MT**2*sw**2)/(6.*cw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'((-5*ee**2*MTA**2 - ee**2*MZ**2 - (cw**2*ee**2*MTA**2)/(2.*sw**2) + (cw**2*ee**2*MZ**2)/(2.*sw**2) + (7*ee**2*MTA**2*sw**2)/(2.*cw**2) + (5*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.u,P.u__tilde__):'(MZ**2*(-(ee**2*MZ**2) + (3*cw**2*ee**2*MZ**2)/(2.*sw**2) + (17*ee**2*MZ**2*sw**2)/(6.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ve,P.ve):'((-8*ee**2*Mnu**2 + 2*ee**2*MZ**2 - (4*cw**2*ee**2*Mnu**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 - (4*ee**2*Mnu**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*Mnu**2*MZ**2 + MZ**4))/(96.*cmath.pi*abs(MZ)**3)',
                                  (P.vm,P.vm):'((-8*ee**2*Mnu**2 + 2*ee**2*MZ**2 - (4*cw**2*ee**2*Mnu**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 - (4*ee**2*Mnu**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*Mnu**2*MZ**2 + MZ**4))/(96.*cmath.pi*abs(MZ)**3)',
                                  (P.vt,P.vt):'((-8*ee**2*Mnu**2 + 2*ee**2*MZ**2 - (4*cw**2*ee**2*Mnu**2)/sw**2 + (cw**2*ee**2*MZ**2)/sw**2 - (4*ee**2*Mnu**2*sw**2)/cw**2 + (ee**2*MZ**2*sw**2)/cw**2)*cmath.sqrt(-4*Mnu**2*MZ**2 + MZ**4))/(96.*cmath.pi*abs(MZ)**3)',
                                  (P.W__minus__,P.W__plus__):'(((-12*cw**2*ee**2*MW**2)/sw**2 - (17*cw**2*ee**2*MZ**2)/sw**2 + (4*cw**2*ee**2*MZ**4)/(MW**2*sw**2) + (cw**2*ee**2*MZ**6)/(4.*MW**4*sw**2))*cmath.sqrt(-4*MW**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)'})

